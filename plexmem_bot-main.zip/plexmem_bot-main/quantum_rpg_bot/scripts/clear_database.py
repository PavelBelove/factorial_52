# quantum_rpg_bot/scripts/clear_database.py

import asyncio
import aiosqlite
import os
import sys

# Добавляем родительскую директорию в sys.path, чтобы иметь доступ к модулям проекта
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import Config

async def clear_database():
    config = Config()
    db_path = config.DB_PATH

    print(f"Очистка базы данных: {db_path}")

    async with aiosqlite.connect(db_path) as db:
        # Получаем список всех таблиц
        async with db.execute("SELECT name FROM sqlite_master WHERE type='table';") as cursor:
            tables = await cursor.fetchall()

        # Очищаем каждую таблицу
        for table in tables:
            table_name = table[0]
            if table_name != 'sqlite_sequence':  # Пропускаем системную таблицу SQLite
                print(f"Очистка таблицы: {table_name}")
                await db.execute(f"DELETE FROM {table_name};")
        
        # Сбрасываем автоинкрементные счетчики
        await db.execute("DELETE FROM sqlite_sequence;")

        await db.commit()

    print("База данных успешно очищена.")

if __name__ == "__main__":
    asyncio.run(clear_database())