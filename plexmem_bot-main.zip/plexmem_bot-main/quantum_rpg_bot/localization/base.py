# quantum_rpg_bot/localization/base.py

from abc import ABC, abstractmethod
from typing import Dict

class BaseLocalization(ABC):
    @abstractmethod
    def get_language_code(self) -> str:
        pass

    @abstractmethod
    def get_language_name(self) -> str:
        pass

    @abstractmethod
    def get_available_languages(self) -> Dict[str, str]:
        pass

    @abstractmethod
    def get_language_selection_message(self) -> str:
        pass

    @abstractmethod
    def get_start_message(self) -> str:
        pass

    @abstractmethod
    def get_main_menu(self) -> dict:
        pass

    @abstractmethod
    def get_world_selection(self) -> str:
        pass

    @abstractmethod
    def get_save_game(self) -> dict:
        pass

    @abstractmethod
    def get_load_game(self) -> dict:
        pass

    @abstractmethod
    def get_rules(self) -> str:
        pass

    @abstractmethod
    def get_back(self) -> str:
        pass

    @abstractmethod
    def get_error_messages(self) -> dict:
        pass

    @abstractmethod
    def get_confirmation_messages(self) -> dict:
        pass

    @abstractmethod
    def get_thinking_message(self) -> str:
        pass

    @abstractmethod
    def get_no_active_game_message(self) -> str:
        pass

    @abstractmethod
    def get_error_message(self) -> str:
        pass

    @abstractmethod
    def get_world_buttons(self) -> dict:
        pass

    @abstractmethod
    def get_world_selection_message(self) -> str:
        pass

    @abstractmethod
    def get_world_descriptions(self) -> dict:
        pass

    @abstractmethod
    def get_not_in_game_message(self) -> str:
        pass

    @abstractmethod
    def get_start_game(self) -> str:
        pass

    @abstractmethod
    def get_game_started_message(self) -> str:
        pass

    @abstractmethod
    def get_initial_game_message(self, world_id: str) -> str:
        pass

    @abstractmethod
    def get_game_overwritten_message(self, slot: int) -> str:
        pass