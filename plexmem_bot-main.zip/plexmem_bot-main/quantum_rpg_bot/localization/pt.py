# quantum_rpg_bot/localization/pt.py

from .base import BaseLocalization

class PortugueseLocalization(BaseLocalization):
    def get_language_code(self) -> str:
        return "pt"

    def get_language_name(self) -> str:
        return "Português"

    def get_available_languages(self) -> dict:
        return {
            "ru": "🇷🇺 Русский",
            "en": "🇬🇧 English",
            "es": "🇪🇸 Español",
            "ar": "🇸🇦 العربية",
            "pt": "🇧🇷 Português",
            "hi": "🇮🇳 हिन्दी"
        }

    def get_language_selection_message(self) -> str:
        return "Escolha seu idioma / Choose your language:"

    def get_start_message(self) -> str:
        return "Bem-vindo ao Factorial 52!"

    def get_main_menu(self) -> dict:
        return {
            "message": "Menu Principal:",
            "new_game": "Novo Jogo",
            "save_game": "Salvar Jogo",
            "load_game": "Carregar Jogo",
            "settings": "Configurações",
            "change_language": "Mudar Idioma"
        }

    def get_world_selection(self) -> str:
        return "Escolha um mundo para o seu novo jogo:"

    def get_save_game(self) -> dict:
        return {
            "message": "Escolha um slot para salvar seu jogo:",
            "slot": "Slot {}",
            "empty": "Vazio"
        }

    def get_load_game(self) -> dict:
        return {
            "message": "Escolha um jogo salvo para carregar:",
            "no_saves": "Você não tem jogos salvos.",
            "slot": "Slot {}",
            "player": "Jogador",
            "assistant": "Assistente",
            "context_reminder": "Aqui estão as últimas jogadas do seu jogo:",
            "no_previous_turns": "Este é um novo jogo. Comece sua aventura!"
        }

    def get_rules(self) -> str:
        return "As regras do jogo estarão aqui."

    def get_back(self) -> str:
        return "Voltar"
    
    def get_save_current_game(self) -> dict:
        return {
            "message": "Você tem um jogo não salvo. Deseja salvá-lo antes de iniciar um novo?",
            "save": "Salvar jogo atual",
            "continue": "Continuar sem salvar"
        }

    def get_error_messages(self) -> dict:
        return {
            "no_active_game": "Erro: não há jogo ativo para salvar.",
            "load_error": "Erro: falha ao carregar o jogo.",
            "save_error": "Erro: falha ao salvar o jogo."
        }

    def get_confirmation_messages(self) -> dict:
        return {
            "overwrite_save": "O slot {} já possui um jogo salvo. Tem certeza que deseja sobrescrevê-lo?",
            "yes": "Sim, sobrescrever",
            "no": "Não, cancelar",
            "save_success": "Jogo salvo no slot {}.",
            "load_success": "Jogo carregado do slot {}. Você pode continuar seu jogo.",
            "save_cancelled": "Salvamento cancelado."
        }
    
    def get_thinking_message(self) -> str:
        return "Pensando na sua resposta..."
    
    def get_no_active_game_message(self) -> str:
        return "Você não tem um jogo ativo. Por favor, inicie um novo jogo."

    def get_error_message(self) -> str:
        return "Ocorreu um erro. Por favor, tente novamente."
    
    def get_world_selection_message(self) -> str:
        return ("Bem-vindo ao Factorial 52!\n\n"
                "Um jogo onde tudo pode acontecer. Um livro onde o enredo depende do leitor. "
                "Escolha um mundo criado apenas para você:\n\n"
                "🧙‍♂️ Belozemie: Onde vive o espírito russo\n\n"
                "🎩 Etheria: Um mundo de steampunk, piratas aéreos e tecnologias a vapor\n\n"
                "🤖 Neo-Terra: Um futuro sombrio de altas tecnologias e problemas sociais\n\n"
                "🏫 Sanctum Nova: Uma antiga academia de magia, cheia de mistérios e aventuras\n\n"
                "🌠 Alterrea: Uma nova vida em um mundo mágico após o renascimento\n\n"
                "🎵 Harmonia: Um mundo único onde tecnologia e forças místicas se entrelaçam através da Ressonância\n\n"
                "Clique no nome de um mundo para saber mais sobre ele.")

    def get_world_buttons(self) -> dict:
        return {
            "slavic": "Belozemie - Fantasia eslava",
            "steampunk": "Etheria - Steampunk",
            "cyberpunk": "Neo-Terra - Cyberpunk",
            "magic_academy": "Sanctum Nova - Academia de Magia",
            "rebirth": "Alterrea - Renascimento",
            "garmonia": "Harmonia - Mundo da Ressonância"
        }

    def get_world_descriptions(self) -> dict:
        return {
            "slavic": ("Bem-vindo a Yarovia - um mundo impregnado de mitologia e magia eslava.\n\n"
                    "Aqui você encontrará poderosos magos, espíritos astutos da floresta e deuses antigos. Torne-se um herói "
                    "capaz de mudar o destino dos principados, lute contra as forças das trevas ou descubra os segredos dos antigos santuários.\n\n"
                    "Sua jornada começa na véspera do grande festival de Kupala, quando as fronteiras entre os mundos se tornam finas, "
                    "e o mal antigo desperta nas profundezas de Chernobor."),

            "steampunk": ("Bem-vindo a Etheria - um mundo de céus infinitos e maravilhas a vapor!\n\n"
                        "Você é o capitão de uma aeronave herdada com uma rica história e má fama. "
                        "Explore ilhas flutuantes, comercialize mercadorias raras ou torne-se o terror dos céus - a escolha é sua!\n\n"
                        "Mas lembre-se, tanto os piratas quanto a frota imperial estão caçando seu navio. Você conseguirá descobrir "
                        "o segredo de sua herança e encontrar seu lugar neste mundo perigoso, mas belo?"),

            "cyberpunk": ("Mergulhe no sombrio mundo de Neo-Terra - um futuro distópico onde a tecnologia "
                        "atingiu alturas sem precedentes, e a humanidade está à beira do abismo.\n\n"
                        "Torne-se parte de um mundo onde a IA governa corporações, desastres ambientais mudam a face do planeta, "
                        "e a desigualdade social atingiu seu pico.\n\n"
                        "Suas ações podem mudar o destino deste mundo. Você se juntará à resistência, "
                        "ficará do lado das corporações ou encontrará seu próprio caminho neste caos?"),

            "magic_academy": ("Bem-vindo a Sanctum Nova - a mais antiga academia de magia, flutuando acima das nuvens!\n\n"
                            "Uma jornada emocionante o aguarda em um mundo onde a magia permeia cada aspecto da vida. "
                            "Torne-se um estudante, estude artes secretas, participe de torneios mágicos e "
                            "descubra os antigos segredos da academia.\n\n"
                            "Mas tenha cuidado: além dos muros da escola, aventuras perigosas o aguardam e um papel importante "
                            "na batalha iminente contra o mal antigo que desperta."),

            "rebirth": ("Abra seus olhos no mundo de Alterrea - um universo mágico onde você se encontra após um renascimento inesperado!\n\n"
                        "Aqui, aventuras incríveis o aguardam como um herói convocado. Desenvolva habilidades únicas, "
                        "reúna uma equipe de aliados leais e explore este novo mundo cheio de magia e perigos.\n\n"
                        "Você conseguirá descobrir o segredo de sua convocação, derrotar o Senhor dos Demônios e salvar Alterrea "
                        "da catástrofe iminente?"),

            "garmonia": ("Bem-vindo a Harmonia - um mundo único onde tecnologia e forças místicas "
                        "se entrelaçam graças a um fenômeno misterioso conhecido como Ressonância.\n\n"
                        "Torne-se um Engenheiro de Ressonância, Eco, Guardião de Cristal ou Camaleão de Ressonância. "
                        "Explore os segredos de artefatos antigos, enfrente a ameaça da Fenda da Discórdia e determine "
                        "o destino deste mundo incrível.\n\n"
                        "Suas decisões afetarão o equilíbrio entre tecnologia e natureza, ordem e caos. "
                        "Você está pronto para ouvir o chamado da Ressonância?")
        }

    def get_not_in_game_message(self) -> str:
        return "Você não está em um jogo no momento. Use o comando /menu para iniciar um novo jogo ou carregar um jogo salvo."

    def get_start_game(self) -> str:
        return "Iniciar jogo"
    
    def get_initial_game_message(self, world_id: str) -> str:
        messages = {
            "slavic": "Sempre responda em português. Fale-me sobre o mundo e os quatro personagens disponíveis para o jogo.",
            "steampunk": "Sempre responda em português. Fale-me sobre o mundo e os quatro personagens disponíveis para o jogo.",
            "cyberpunk": "Sempre responda em português. Fale-me sobre o mundo e os quatro personagens disponíveis para o jogo.",
            "magic_academy": "Sempre responda em português. Fale-me sobre o mundo e os quatro personagens disponíveis para o jogo.",
            "rebirth": "Sempre responda em português. Fale-me sobre o mundo e os quatro personagens disponíveis para o jogo.",
            "garmonia": "Sempre responda em português. Fale-me sobre o mundo e os quatro personagens disponíveis para o jogo."     
        }
        return messages.get(world_id)
    
    def get_game_overwritten_message(self, slot: int) -> str:
        return f"Aviso: o novo jogo sobrescreveu o jogo salvo existente no slot {slot}."

    def get_game_started_message(self, slot: int) -> str:
        return f"Novo jogo salvo no slot {slot}. \n Um momento, criando seu mundo de jogo único"