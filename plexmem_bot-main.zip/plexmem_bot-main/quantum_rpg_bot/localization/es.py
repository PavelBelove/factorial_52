# quantum_rpg_bot/localization/es.py

from .base import BaseLocalization

class SpanishLocalization(BaseLocalization):
    def get_language_code(self) -> str:
        return "es"

    def get_language_name(self) -> str:
        return "Español"

    def get_available_languages(self) -> dict:
        return {
            "ru": "🇷🇺 Русский",
            "en": "🇬🇧 English",
            "es": "🇪🇸 Español",
            "ar": "🇸🇦 العربية",
            "pt": "🇧🇷 Português",
            "hi": "🇮🇳 हिन्दी"
        }

    def get_language_selection_message(self) -> str:
        return "Elige tu idioma / Choose your language:"

    def get_start_message(self) -> str:
        return "¡Bienvenido a Factorial 52!"

    def get_main_menu(self) -> dict:
        return {
            "message": "Menú Principal:",
            "new_game": "Nuevo Juego",
            "save_game": "Guardar Juego",
            "load_game": "Cargar Juego",
            "settings": "Configuración",
            "change_language": "Cambiar Idioma"
        }

    def get_world_selection(self) -> str:
        return "Elige un mundo para tu nuevo juego:"

    def get_save_game(self) -> dict:
        return {
            "message": "Elige una ranura para guardar tu juego:",
            "slot": "Ranura {}",
            "empty": "Vacía"
        }

    def get_load_game(self) -> dict:
        return {
            "message": "Elige un juego guardado para cargar:",
            "no_saves": "No tienes juegos guardados.",
            "slot": "Ranura {}",
            "player": "Jugador",
            "assistant": "Asistente",
            "context_reminder": "Aquí están los últimos turnos de tu juego:",
            "no_previous_turns": "Este es un nuevo juego. ¡Comienza tu aventura!"
        }

    def get_rules(self) -> str:
        return "Las reglas del juego estarán aquí."

    def get_back(self) -> str:
        return "Atrás"
    
    def get_save_current_game(self) -> dict:
        return {
            "message": "Tienes un juego sin guardar. ¿Quieres guardarlo antes de comenzar uno nuevo?",
            "save": "Guardar juego actual",
            "continue": "Continuar sin guardar"
        }

    def get_error_messages(self) -> dict:
        return {
            "no_active_game": "Error: no hay un juego activo para guardar.",
            "load_error": "Error: no se pudo cargar el juego.",
            "save_error": "Error: no se pudo guardar el juego."
        }

    def get_confirmation_messages(self) -> dict:
        return {
            "overwrite_save": "La ranura {} ya tiene un juego guardado. ¿Estás seguro de que quieres sobrescribirlo?",
            "yes": "Sí, sobrescribir",
            "no": "No, cancelar",
            "save_success": "Juego guardado en la ranura {}.",
            "load_success": "Juego cargado de la ranura {}. Puedes continuar tu juego.",
            "save_cancelled": "Guardado cancelado."
        }
    
    def get_thinking_message(self) -> str:
        return "Pensando en tu respuesta..."
    
    def get_no_active_game_message(self) -> str:
        return "No tienes un juego activo. Por favor, inicia un nuevo juego."

    def get_error_message(self) -> str:
        return "Ocurrió un error. Por favor, inténtalo de nuevo."
    
    def get_world_selection_message(self) -> str:
        return ("¡Bienvenido a Factorial 52!\n\n"
                "Un juego donde todo puede suceder. Un libro donde la trama depende del lector. "
                "Elige un mundo creado solo para ti:\n\n"
                "🧙‍♂️ Belozemie: Donde vive el espíritu ruso\n\n"
                "🎩 Etheria: Un mundo de steampunk, piratas aéreos y tecnologías de vapor\n\n"
                "🤖 Neo-Terra: Un futuro oscuro de altas tecnologías y problemas sociales\n\n"
                "🏫 Sanctum Nova: Una antigua academia de magia, llena de misterios y aventuras\n\n"
                "🌠 Alterrea: Una nueva vida en un mundo mágico después del renacimiento\n\n"
                "🎵 Armonía: Un mundo único donde la tecnología y las fuerzas místicas se entrelazan a través de la Resonancia\n\n"
                "Haz clic en el nombre de un mundo para obtener más información.")

    def get_world_buttons(self) -> dict:
        return {
            "slavic": "Belozemie - Fantasía eslava",
            "steampunk": "Etheria - Steampunk",
            "cyberpunk": "Neo-Terra - Cyberpunk",
            "magic_academy": "Sanctum Nova - Academia de Magia",
            "rebirth": "Alterrea - Renacimiento",
            "garmonia": "Armonía - Mundo de la Resonancia"
        }

    def get_world_descriptions(self) -> dict:
        return {
            "slavic": ("Bienvenido a Yarovia, un mundo impregnado de mitología y magia eslava.\n\n"
                    "Aquí conocerás a poderosos magos, astutos espíritus del bosque y antiguos dioses. Conviértete en un héroe "
                    "capaz de cambiar el destino de los principados, lucha contra las fuerzas oscuras o descubre los secretos de los antiguos santuarios.\n\n"
                    "Tu viaje comienza en la víspera del gran festival de Kupala, cuando los límites entre mundos se adelgazan "
                    "y el mal antiguo despierta en las profundidades de Chernobor."),

            "steampunk": ("¡Bienvenido a Etheria, un mundo de cielos infinitos y maravillas de vapor!\n\n"
                        "Eres el capitán de una nave aérea heredada con una rica historia y mala fama. "
                        "Explora islas flotantes, comercia con productos raros o conviértete en el terror de los cielos - ¡la elección es tuya!\n\n"
                        "Pero recuerda, tanto los piratas como la flota imperial están cazando tu nave. ¿Podrás descubrir "
                        "el secreto de tu herencia y encontrar tu lugar en este mundo peligroso pero hermoso?"),

            "cyberpunk": ("Sumérgete en el sombrío mundo de Neo-Terra, un futuro distópico donde la tecnología "
                        "ha alcanzado alturas sin precedentes y la humanidad está al borde del abismo.\n\n"
                        "Forma parte de un mundo donde la IA gobierna las corporaciones, los desastres ambientales cambian la faz del planeta "
                        "y la desigualdad social ha alcanzado su punto máximo.\n\n"
                        "Tus acciones pueden cambiar el destino de este mundo. ¿Te unirás a la resistencia, "
                        "te pondrás del lado de las corporaciones o encontrarás tu propio camino en este caos?"),

            "magic_academy": ("¡Bienvenido a Sanctum Nova, la academia de magia más antigua, flotando sobre las nubes!\n\n"
                            "Te espera un emocionante viaje en un mundo donde la magia impregna cada aspecto de la vida. "
                            "Conviértete en estudiante, estudia artes secretas, participa en torneos mágicos y "
                            "descubre los antiguos secretos de la academia.\n\n"
                            "Pero ten cuidado: más allá de los muros de la escuela, te esperan peligrosas aventuras y un papel importante "
                            "en la próxima batalla contra el antiguo mal que despierta."),

            "rebirth": ("¡Abre los ojos en el mundo de Alterrea, un universo mágico donde te encuentras después de un renacimiento inesperado!\n\n"
                        "Aquí te esperan increíbles aventuras como un héroe invocado. Desarrolla habilidades únicas, "
                        "reúne un equipo de aliados leales y explora este nuevo mundo lleno de magia y peligros.\n\n"
                        "¿Podrás descubrir el secreto de tu invocación, derrotar al Señor de los Demonios y salvar Alterrea "
                        "de la catástrofe inminente?"),

            "garmonia": ("Bienvenido a Armonía, un mundo único donde la tecnología y las fuerzas místicas "
                        "se entrelazan gracias a un fenómeno misterioso conocido como Resonancia.\n\n"
                        "Conviértete en un Ingeniero de Resonancia, Eco, Guardián de Cristal o Camaleón de Resonancia. "
                        "Explora los secretos de los artefactos antiguos, enfrenta la amenaza de la Grieta de la Discordia y determina "
                        "el destino de este asombroso mundo.\n\n"
                        "Tus decisiones afectarán el equilibrio entre la tecnología y la naturaleza, el orden y el caos. "
                        "¿Estás listo para escuchar la llamada de la Resonancia?")
        }

    def get_not_in_game_message(self) -> str:
        return "No estás actualmente en un juego. Usa el comando /menu para iniciar un nuevo juego o cargar uno guardado."

    def get_start_game(self) -> str:
        return "Iniciar juego"
    
    def get_initial_game_message(self, world_id: str) -> str:
        messages = {
            "slavic": "Responde siempre en español. Háblame sobre el mundo y los cuatro personajes disponibles para el juego.",
            "steampunk": "Responde siempre en español. Háblame sobre el mundo y los cuatro personajes disponibles para el juego.",
            "cyberpunk": "Responde siempre en español. Háblame sobre el mundo y los cuatro personajes disponibles para el juego.",
            "magic_academy": "Responde siempre en español. Háblame sobre el mundo y los cuatro personajes disponibles para el juego.",
            "rebirth": "Responde siempre en español. Háblame sobre el mundo y los cuatro personajes disponibles para el juego.",
            "garmonia": "Responde siempre en español. Háblame sobre el mundo y los cuatro personajes disponibles para el juego."     
        }
        return messages.get(world_id)
    
    def get_game_overwritten_message(self, slot: int) -> str:
        return f"Advertencia: el nuevo juego ha sobrescrito el guardado existente en la ranura {slot}."

    def get_game_started_message(self, slot: int) -> str:
        return f"Nuevo juego guardado en la ranura {slot}. \n Un momento, creando tu mundo de juego único"