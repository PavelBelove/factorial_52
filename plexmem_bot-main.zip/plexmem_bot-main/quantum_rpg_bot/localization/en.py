# quantum_rpg_bot/localization/en.py

from .base import BaseLocalization

class EnglishLocalization(BaseLocalization):
    def get_language_code(self) -> str:
        return "en"

    def get_language_name(self) -> str:
        return "English"

    def get_available_languages(self) -> dict:
        return {
            "ru": "🇷🇺 Русский",
            "en": "🇬🇧 English",
            "es": "🇪🇸 Español",
            "ar": "🇸🇦 العربية",
            "pt": "🇧🇷 Português",
            "hi": "🇮🇳 हिन्दी"
        }

    def get_language_selection_message(self) -> str:
        return "Choose your language / Выберите язык:"

    def get_start_message(self) -> str:
        return "Welcome to Factorial 52!"

    def get_main_menu(self) -> dict:
        return {
            "message": "Main Menu:",
            "new_game": "New Game",
            "save_game": "Save Game",
            "load_game": "Load Game",
            "settings": "Settings",
            "change_language": "Change Language"
        }

    def get_world_selection(self) -> str:
        return "Choose a world for your new game:"

    def get_save_game(self) -> dict:
        return {
            "message": "Choose a slot to save your game:",
            "slot": "Slot {}",
            "empty": "Empty"
        }

    def get_load_game(self) -> dict:
        return {
            "message": "Choose a save to load:",
            "no_saves": "You have no saved games.",
            "slot": "Slot {}",
            "player": "Player",
            "assistant": "Assistant",
            "context_reminder": "Here are the last turns of your game:",
            "no_previous_turns": "This is a new game. Start your adventure!"
        }

    def get_rules(self) -> str:
        return "Game rules will be here."

    def get_back(self) -> str:
        return "Back"
    
    def get_save_current_game(self) -> dict:
        return {
            "message": "You have an unsaved game. Do you want to save it before starting a new one?",
            "save": "Save current game",
            "continue": "Continue without saving"
        }

    def get_error_messages(self) -> dict:
        return {
            "no_active_game": "Error: no active game to save.",
            "load_error": "Error: failed to load the game.",
            "save_error": "Error: failed to save the game."
        }

    def get_confirmation_messages(self) -> dict:
        return {
            "overwrite_save": "Slot {} already has a save. Are you sure you want to overwrite it?",
            "yes": "Yes, overwrite",
            "no": "No, cancel",
            "save_success": "Game saved to slot {}.",
            "load_success": "Game loaded from slot {}. You can continue your game.",
            "save_cancelled": "Save cancelled."
        }
    
    def get_thinking_message(self) -> str:
        return "Thinking about your response..."
    
    def get_no_active_game_message(self) -> str:
        return "You don't have an active game. Please start a new game."

    def get_error_message(self) -> str:
        return "An error occurred. Please try again."
    
    def get_world_selection_message(self) -> str:
        return ("Welcome to Factorial 52!\n\n"
                "A game where anything can happen. A book where the plot depends on the reader. "
                "Choose a world created just for you:\n\n"
                "🧙‍♂️ Belozemie: Where Russian spirit lives\n\n"
                "🎩 Etheria: A world of steampunk, air pirates, and steam technologies\n\n"
                "🤖 Neo-Terra: A dark future of high technologies and social problems\n\n"
                "🏫 Sanctum Nova: An ancient academy of magic, full of mysteries and adventures\n\n"
                "🌠 Alterrea: A new life in a magical world after rebirth\n\n"
                "🎵 Harmony: A unique world where technology and mystical forces intertwine through Resonance\n\n"
                "Click on a world's name to learn more about it.")

    def get_world_buttons(self) -> dict:
        return {
            "slavic": "Belozemie - Slavic fantasy",
            "steampunk": "Etheria - Steampunk",
            "cyberpunk": "Neo-Terra - Cyberpunk",
            "magic_academy": "Sanctum Nova - Magic Academy",
            "rebirth": "Alterrea - Rebirth",
            "garmonia": "Harmony - World of Resonance"
        }

    def get_world_descriptions(self) -> dict:
        return {
            "slavic": ("Welcome to Yarovia - a world steeped in Slavic mythology and magic.\n\n"
                    "Here you'll meet powerful mages, cunning forest spirits, and ancient gods. Become a hero "
                    "capable of changing the fate of principalities, fight dark forces, or uncover the secrets of ancient sanctuaries.\n\n"
                    "Your journey begins on the eve of the great Kupala festival, when the boundaries between worlds thin, "
                    "and ancient evil awakens in the depths of Chernobor."),

            "steampunk": ("Welcome to Etheria - a world of endless skies and steam wonders!\n\n"
                        "You are the captain of an inherited airship with a rich history and ill fame. "
                        "Explore floating islands, trade rare goods, or become the terror of the skies - the choice is yours!\n\n"
                        "But remember, both pirates and the imperial fleet are hunting for your ship. Can you uncover "
                        "the secret of your inheritance and find your place in this dangerous but beautiful world?"),

            "cyberpunk": ("Immerse yourself in the grim world of Neo-Terra - a dystopian future where technology "
                        "has reached unprecedented heights, and humanity is on the brink.\n\n"
                        "Become part of a world where AI rules corporations, environmental disasters change the face of the planet, "
                        "and social inequality has reached its peak.\n\n"
                        "Your actions can change the fate of this world. Will you join the resistance, "
                        "side with corporations, or find your own path in this chaos?"),

            "magic_academy": ("Welcome to Sanctum Nova - the oldest academy of magic, floating above the clouds!\n\n"
                            "An exciting journey awaits you in a world where magic permeates every aspect of life. "
                            "Become a student, study secret arts, participate in magical tournaments, and "
                            "uncover the ancient secrets of the academy.\n\n"
                            "But be careful: beyond the school walls, dangerous adventures await you and an important role "
                            "in the coming battle with awakening ancient evil."),

            "rebirth": ("Open your eyes in the world of Alterrea - a magical universe where you found yourself after an unexpected rebirth!\n\n"
                        "Here, incredible adventures await you as a summoned hero. Develop unique abilities, "
                        "gather a team of loyal allies, and explore this new world full of magic and dangers.\n\n"
                        "Can you uncover the secret of your summoning, defeat the Demon Lord, and save Alterrea "
                        "from the impending catastrophe?"),

            "garmonia": ("Welcome to Harmony - a unique world where technology and mystical forces "
                        "intertwine thanks to a mysterious phenomenon known as Resonance.\n\n"
                        "Become a Resonance Engineer, Echo, Crystal Guardian, or Resonance Chameleon. "
                        "Explore the secrets of ancient artifacts, confront the threat of the Discord Rift, and determine "
                        "the fate of this amazing world.\n\n"
                        "Your decisions will affect the balance between technology and nature, order and chaos. "
                        "Are you ready to hear the call of Resonance?")
        }

    def get_not_in_game_message(self) -> str:
        return "You are not currently in a game. Use the /menu command to start a new game or load a save."

    def get_start_game(self) -> str:
        return "Start game"
    
    def get_initial_game_message(self, world_id: str) -> str:
        messages = {
            "slavic": "Always respond in English. Tell me about the world and the four characters available for the game.",
            "steampunk": "Always respond in English. Tell me about the world and the four characters available for the game.",
            "cyberpunk": "Always respond in English. Tell me about the world and the four characters available for the game.",
            "magic_academy": "Always respond in English. Tell me about the world and the four characters available for the game.",
            "rebirth": "Always respond in English. Tell me about the world and the four characters available for the game.",
            "garmonia": "Always respond in English. Tell me about the world and the four characters available for the game."     
        }
        return messages.get(world_id)
    
    def get_game_overwritten_message(self, slot: int) -> str:
        return f"Warning: the new game has overwritten the existing save in slot {slot}."

    def get_game_started_message(self, slot: int) -> str:
        return f"New game saved in slot {slot}. \n Just a moment, creating your unique game world"