# quantum_rpg_bot/database.py

"""
Модуль для работы с базой данных SQLite.
Обеспечивает хранение и извлечение данных для работы бота.
"""

import aiosqlite
import json
from typing import List, Dict, Any, Optional

class Database:
    def __init__(self, db_path: str):
        """
        Инициализирует объект базы данных.

        Args:
            db_path (str): Путь к файлу базы данных SQLite.
        """
        self.db_path = db_path

    async def initialize(self):
        """
        Инициализирует структуру базы данных, создавая необходимые таблицы.
        """
        async with aiosqlite.connect(self.db_path) as db:
            # Обновление таблицы games
            await db.execute("""
                CREATE TABLE IF NOT EXISTS games (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    world_id TEXT,
                    world_description TEXT,
                    summary TEXT,
                    slot INTEGER,
                    saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(user_id, slot)
                )
            """)
            
            # Обновление таблицы turns
            await db.execute("""
                CREATE TABLE IF NOT EXISTS turns (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    game_id INTEGER,
                    user_id INTEGER,
                    user_message TEXT,
                    assistant_response TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(game_id) REFERENCES games(id)
                )
            """)

            # Обновление таблицы states
            await db.execute("""
                CREATE TABLE IF NOT EXISTS states (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    game_id INTEGER,
                    user_id INTEGER,
                    state JSON,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(game_id) REFERENCES games(id)
                )
            """)

            # Обновление таблицы summaries
            await db.execute("""
                CREATE TABLE IF NOT EXISTS summaries (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    game_id INTEGER,
                    summary TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(game_id) REFERENCES games(id)
                )
            """)

            # Обновление таблицы quanta
            await db.execute("""
                CREATE TABLE IF NOT EXISTS quanta (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    game_id INTEGER,
                    user_id INTEGER,
                    name TEXT,
                    type TEXT,
                    summary TEXT,
                    details JSON,
                    related_quanta JSON,
                    attention INTEGER,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(game_id) REFERENCES games(id)
                )
            """)

            # Создание таблицы user_state
            await db.execute("""
                CREATE TABLE IF NOT EXISTS user_state (
                    user_id INTEGER PRIMARY KEY,
                    current_game_id INTEGER,
                    last_save_flag BOOLEAN DEFAULT FALSE,
                    FOREIGN KEY(current_game_id) REFERENCES games(id)
                )
            """)

            await db.commit()

    async def create_new_game(self, user_id: int, world_id: str) -> int:
        """
        Создает новую игру для пользователя в первом свободном слоте.
        Если свободных слотов нет, перезаписывает самую старую игру.
        """
        async with aiosqlite.connect(self.db_path) as db:
            try:
                # Находим первый свободный слот или самую старую игру
                cursor = await db.execute("""
                    SELECT slot FROM games
                    WHERE user_id = ?
                    ORDER BY slot ASC
                """, (user_id,))
                existing_slots = [row[0] async for row in cursor]
                
                if not existing_slots:
                    new_slot = 1
                elif len(existing_slots) < 5:
                    new_slot = next(i for i in range(1, 6) if i not in existing_slots)
                else:
                    # Если все слоты заняты, перезаписываем самую старую игру
                    cursor = await db.execute("""
                        SELECT slot FROM games
                        WHERE user_id = ?
                        ORDER BY saved_at ASC
                        LIMIT 1
                    """, (user_id,))
                    row = await cursor.fetchone()
                    new_slot = row[0] if row else 1
                
                # Создаем или перезаписываем игру
                cursor = await db.execute("""
                    INSERT OR REPLACE INTO games (user_id, world_id, world_description, summary, slot, saved_at)
                    VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                """, (user_id, world_id, "", "", new_slot))
                
                await db.commit()
                return cursor.lastrowid
            except Exception as e:
                print(f"Ошибка при создании новой игры: {e}")
                raise

    async def save_game(self, user_id: int, game_id: int, world_id: str, world_description: str, slot: int) -> None:
        """
        Сохраняет или обновляет игру в базе данных.
        """
        async with aiosqlite.connect(self.db_path) as db:
            try:
                await db.execute("""
                    UPDATE games
                    SET world_id = ?, world_description = ?, saved_at = CURRENT_TIMESTAMP
                    WHERE id = ? AND user_id = ?
                """, (world_id, world_description, game_id, user_id))
                await db.commit()
            except Exception as e:
                print(f"Ошибка при сохранении игры: {e}")
                raise

    async def load_game(self, user_id: int, game_id: int) -> Optional[Dict[str, Any]]:
        """
        Загружает игру из базы данных.
        """
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute("""
                SELECT id, world_id, world_description, summary, slot, saved_at
                FROM games
                WHERE id = ? AND user_id = ?
            """, (game_id, user_id))
            row = await cursor.fetchone()
            if row:
                return {
                    "id": row[0],
                    "world_id": row[1],
                    "world_description": row[2],
                    "summary": row[3],
                    "slot": row[4],
                    "saved_at": row[5]
                }
            return None

    async def get_user_games(self, user_id: int) -> List[Dict[str, Any]]:
        """
        Получает список всех сохраненных игр пользователя.

        Args:
            user_id (int): ID пользователя.

        Returns:
            List[Dict[str, Any]]: Список сохраненных игр.
        """
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute("""
                SELECT id, world_id, slot, saved_at
                FROM games
                WHERE user_id = ?
                ORDER BY slot
            """, (user_id,))
            rows = await cursor.fetchall()
            return [{"id": row[0], "world_id": row[1], "slot": row[2], "saved_at": row[3]} for row in rows]
        
    async def user_exists(self, user_id: int) -> bool:
        """
        Проверяет, существует ли пользователь в базе данных.
        """
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute("SELECT COUNT(*) FROM user_state WHERE user_id = ?", (user_id,))
            result = await cursor.fetchone()
            return result[0] > 0

    async def get_all_active_users(self) -> List[Dict[str, Any]]:
        """
        Получает список всех активных пользователей
        """
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute("""
                SELECT DISTINCT user_id 
                FROM user_state 
                WHERE current_game_id IS NOT NULL
            """)
            rows = await cursor.fetchall()
        return [{'id': row[0]} for row in rows]

    async def get_game_info(self, game_id: int) -> Dict[str, Any]:
        """
        Получает информацию об игре по ее ID.

        Args:
            game_id (int): ID игры.

        Returns:
            Dict[str, Any]: Информация об игре.
        """
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute("""
                SELECT id, user_id, world_id, slot, saved_at
                FROM games
                WHERE id = ?
            """, (game_id,))
            row = await cursor.fetchone()
            if row:
                return {
                    "id": row[0],
                    "user_id": row[1],
                    "world_id": row[2],
                    "slot": row[3],
                    "saved_at": row[4]
                }
            return None
        
    async def get_game_in_slot(self, user_id: int, slot: int) -> Optional[Dict[str, Any]]:
        """
        Получает информацию об игре в указанном слоте.
        """
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute("""
                SELECT id, world_id, saved_at
                FROM games
                WHERE user_id = ? AND slot = ?
            """, (user_id, slot))
            row = await cursor.fetchone()
            if row:
                return {
                    "id": row[0],
                    "world_id": row[1],
                    "saved_at": row[2]
                }
            return None

    async def update_user_state(self, user_id: int, current_game_id: int, last_save_flag: bool):
        """
        Обновляет состояние пользователя.

        Args:
            user_id (int): ID пользователя.
            current_game_id (int): ID текущей активной игры.
            last_save_flag (bool): Флаг, указывающий, была ли игра сохранена в текущей сессии.
        """
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT OR REPLACE INTO user_state (user_id, current_game_id, last_save_flag)
                VALUES (?, ?, ?)
            """, (user_id, current_game_id, last_save_flag))
            await db.commit()

    async def get_user_state(self, user_id: int) -> Optional[Dict[str, Any]]:
        """
        Получает текущее состояние пользователя.

        Args:
            user_id (int): ID пользователя.

        Returns:
            Optional[Dict[str, Any]]: Состояние пользователя или None, если не найдено.
        """
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute("""
                SELECT current_game_id, last_save_flag
                FROM user_state
                WHERE user_id = ?
            """, (user_id,))
            row = await cursor.fetchone()
            if row:
                return {"current_game_id": row[0], "last_save_flag": bool(row[1])}
            return None

    async def save_turn(self, game_id: int, user_id: int, user_message: str, assistant_response: str):
        """
        Сохраняет ход диалога в базу данных.

        Args:
            game_id (int): ID игры.
            user_id (int): ID пользователя.
            user_message (str): Сообщение пользователя.
            assistant_response (str): Ответ ассистента.
        """
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "INSERT INTO turns (game_id, user_id, user_message, assistant_response) VALUES (?, ?, ?, ?)",
                (game_id, user_id, user_message, assistant_response)
            )
            await db.commit()

    async def get_recent_turns(self, game_id: int, num_turns: int) -> List[Dict[str, Any]]:
        """
        Получает последние ходы диалога для игры.

        Args:
            game_id (int): ID игры.
            num_turns (int): Количество запрашиваемых ходов.

        Returns:
            List[Dict[str, Any]]: Список последних ходов диалога.
        """
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT user_message, assistant_response FROM turns WHERE game_id = ? ORDER BY id DESC LIMIT ?",
                (game_id, num_turns)
            )
            turns = await cursor.fetchall()
        return [{"user_message": turn[0], "assistant_response": turn[1]} for turn in reversed(turns)]
    
    async def get_last_two_turns(self, game_id: int) -> List[Dict[str, str]]:
        """
        Получает последние два хода диалога для игры.

        Args:
            game_id (int): ID игры.

        Returns:
            List[Dict[str, str]]: Список последних двух ходов диалога.
        """
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(
                "SELECT user_message, assistant_response FROM turns WHERE game_id = ? ORDER BY id DESC LIMIT 2",
                (game_id,)
            ) as cursor:
                turns = await cursor.fetchall()
        return [{"user_message": turn[0], "assistant_response": turn[1]} for turn in reversed(turns)]

    async def save_state(self, game_id: int, state: Dict[str, Any]):
        """
        Сохраняет состояние для игры.

        Args:
            game_id (int): ID игры.
            state (Dict[str, Any]): Состояние для сохранения.
        """
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "INSERT INTO states (game_id, state) VALUES (?, ?)",
                (game_id, json.dumps(state))
            )
            await db.commit()

    async def get_current_state(self, game_id: int) -> Optional[Dict[str, Any]]:
        """
        Получает текущее состояние для игры.

        Args:
            game_id (int): ID игры.

        Returns:
            Optional[Dict[str, Any]]: Текущее состояние или None, если состояние не найдено.
        """
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT state FROM states WHERE game_id = ? ORDER BY id DESC LIMIT 1",
                (game_id,)
            )
            result = await cursor.fetchone()
        return json.loads(result[0]) if result and result[0] else None

    async def save_summary(self, game_id: int, summary: str):
        """
        Сохраняет суммаризацию для игры.

        Args:
            game_id (int): ID игры.
            summary (str): Текст суммаризации.
        """
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "INSERT INTO summaries (game_id, summary) VALUES (?, ?)",
                (game_id, summary)
            )
            await db.commit()

    async def get_latest_summary(self, game_id: int) -> Optional[str]:
        """
        Получает последнюю суммаризацию для игры.

        Args:
            game_id (int): ID игры.

        Returns:
            Optional[str]: Последняя суммаризация или None, если суммаризация не найдена.
        """
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT summary FROM summaries WHERE game_id = ? ORDER BY id DESC LIMIT 1",
                (game_id,)
            )
            result = await cursor.fetchone()
        return json.loads(result[0]) if result and result[0] else None

    async def save_quantum(self, game_id: int, name: str, quantum_data: Dict[str, Any]) -> None:
        """
        Сохраняет квант в базу данных.

        Args:
            game_id (int): ID игры.
            name (str): Уникальное имя кванта.
            quantum_data (Dict[str, Any]): Данные кванта.
        """
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                """
                INSERT OR REPLACE INTO quanta 
                (game_id, name, type, summary, details, related_quanta, attention) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (game_id, name, quantum_data.get('type'), quantum_data.get('summary'), 
                json.dumps(quantum_data.get('details', {}), ensure_ascii=False),
                json.dumps(quantum_data.get('related_quanta', {}), ensure_ascii=False),
                quantum_data.get('attention', 5))
            )
            await db.commit()

    async def get_quantum(self, game_id: int, name: str) -> Optional[Dict[str, Any]]:
        """
        Получает квант из базы данных.

        Args:
            game_id (int): ID игры.
            name (str): Уникальное имя кванта.

        Returns:
            Optional[Dict[str, Any]]: Данные кванта или None, если квант не найден.
        """
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(
                "SELECT * FROM quanta WHERE game_id = ? AND name = ?",
                (game_id, name)
            ) as cursor:
                result = await cursor.fetchone()
        
        if result:
            columns = ['id', 'game_id', 'name', 'type', 'summary', 'details', 'related_quanta', 'attention', 'timestamp']
            quantum = dict(zip(columns, result))
            return quantum
        return None
    
    async def update_quantum_attention(self, game_id: int, name: str, attention: int) -> None:
        """
        Обновляет уровень внимания кванта.

        Args:
            game_id (int): ID игры.
            name (str): Уникальное имя кванта.
            attention (int): Новый уровень внимания.
        """
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "UPDATE quanta SET attention = ? WHERE game_id = ? AND name = ?",
                (attention, game_id, name)
            )
            await db.commit()

    async def remove_low_attention_quanta(self, game_id: int, threshold: int) -> None:
        """
        Удаляет кванты с уровнем внимания ниже порогового значения.

        Args:
            game_id (int): ID игры.
            threshold (int): Пороговое значение внимания.
        """
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "DELETE FROM quanta WHERE game_id = ? AND attention < ?",
                (game_id, threshold)
            )
            await db.commit()

    async def get_all_quanta(self, game_id: int) -> List[Dict[str, Any]]:
        """
        Получает все кванты для указанной игры.

        Args:
            game_id (int): ID игры.

        Returns:
            List[Dict[str, Any]]: Список всех квантов игры.
        """
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(
                "SELECT * FROM quanta WHERE game_id = ?",
                (game_id,)
            ) as cursor:
                results = await cursor.fetchall()
        
        columns = ['id', 'game_id', 'name', 'type', 'summary', 'details', 'related_quanta', 'attention', 'timestamp']
        quanta = []
        for result in results:
            quantum = dict(zip(columns, result))
            quantum['details'] = json.loads(quantum['details'])
            quantum['related_quanta'] = json.loads(quantum['related_quanta'])
            quanta.append(quantum)
        return quanta

    async def update_quantum(self, game_id: int, name: str, updates: Dict[str, Any]):
        """
        Обновляет существующий квант.

        Args:
            game_id (int): ID игры.
            name (str): Уникальное имя кванта.
            updates (Dict[str, Any]): Словарь с обновлениями для кванта.
        """
        current_quantum = await self.get_quantum(game_id, name)
        if current_quantum:
            current_quantum.update(updates)
            await self.save_quantum(game_id, current_quantum['user_id'], name, current_quantum)

    async def get_all_quanta(self, game_id: int) -> List[Dict[str, Any]]:
        """
        Получает все кванты для указанной игры.

        Args:
            game_id (int): ID игры.

        Returns:
            List[Dict[str, Any]]: Список всех квантов игры.
        """
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(
                "SELECT * FROM quanta WHERE game_id = ?",
                (game_id,)
            ) as cursor:
                results = await cursor.fetchall()
        
        columns = ['id', 'game_id', 'user_id', 'name', 'type', 'summary', 'details', 'related_quanta', 'attention', 'timestamp']
        quanta = []
        for result in results:
            quantum = dict(zip(columns, result))
            quantum['details'] = json.loads(quantum['details'])
            quantum['related_quanta'] = json.loads(quantum['related_quanta'])
            quanta.append(quantum)
        return quanta