# quantum_rpg_bot/agents/fixer_agent.py

import json
import hjson
import logging
import os
import re
from typing import Dict, Any, Optional
from config import Config
from llm_clients.base_client import BaseLLMClient

class FixerAgent:
    """
    Агент для исправления и обработки JSON-ответов.
    
    Этот класс объединяет функциональность обработки JSON и его исправления,
    используя различные методы, включая языковую модель в крайних случаях.
    """

    def __init__(self, config: Config, llm_client: BaseLLMClient):
        """
        Инициализация FixerAgent.

        Args:
            config (Config): Объект конфигурации.
            llm_client (BaseLLMClient): Клиент для взаимодействия с языковой моделью.
        """
        self.config = config
        self.llm_client = llm_client
        self.logger = logging.getLogger(__name__)
        self.fix_prompts = self._load_fix_prompts()

    def _load_fix_prompts(self) -> Dict[str, str]:
        """
        Загружает промпты для исправления JSON из файлов.

        Returns:
            Dict[str, str]: Словарь с промптами для разных типов агентов.
        """
        fix_prompts = {}
        fix_prompts_dir = os.path.join(self.config.PROMPTS_DIR, 'fixing')
        prompt_files = {
            'dialog': 'fix_dialog_prompt.txt',
            'summarization': 'fix_summarization_prompt.txt'
        }
        for agent_type, filename in prompt_files.items():
            file_path = os.path.join(fix_prompts_dir, filename)
            if os.path.exists(file_path):
                with open(file_path, 'r', encoding='utf-8') as file:
                    fix_prompts[agent_type] = file.read().strip()
            else:
                self.logger.warning(f"Файл промпта не найден: {file_path}")
        
        self.logger.info(f"Загружены промпты для исправления: {', '.join(fix_prompts.keys())}")
        return fix_prompts

    async def process_and_fix_json(self, raw_json: str, agent_type: Optional[str] = None) -> Optional[Dict[str, Any]]:
        self.logger.info(f"Начало обработки JSON" + (f" для агента {agent_type}" if agent_type else ""))
        self.logger.debug(f"Исходный JSON: {raw_json}")

        # Шаг 1: Предварительная обработка
        preprocessed_json = self._preprocess_json(raw_json)
        self.logger.debug(f"Предобработанный JSON: {preprocessed_json}")

        # Шаг 2: Обработка текстовой части (для диалогового агента)
        if agent_type == 'dialog':
            preprocessed_json = self._process_dialog_response(preprocessed_json)
            self.logger.debug(f"JSON после обработки response: {preprocessed_json}")

        # Шаг 3: Попытка стандартного парсинга
        try:
            parsed_json = json.loads(preprocessed_json)
            self.logger.info("JSON успешно обработан стандартным парсером")
            return parsed_json
        except json.JSONDecodeError as e:
            self.logger.warning(f"Ошибка парсинга стандартным JSON: {e}")

        # Шаг 4: Попытка парсинга с помощью hjson
        try:
            parsed_hjson = hjson.loads(preprocessed_json)
            if isinstance(parsed_hjson, dict):
                self.logger.info("JSON успешно обработан с помощью hjson и преобразован в валидный JSON")
                return parsed_hjson
            else:
                self.logger.warning(f"hjson вернул не словарь, а {type(parsed_hjson)}")
        except hjson.HjsonDecodeError as e:
            self.logger.warning(f"Ошибка парсинга с помощью hjson: {e}")

        # Шаг 5: Использование языковой модели для исправления
        if agent_type and agent_type in self.fix_prompts:
            try:
                fixed_json = await self._fix_json_with_llm(preprocessed_json, agent_type)
                if fixed_json:
                    self.logger.info("JSON успешно исправлен с помощью языковой модели")
                    return fixed_json
            except Exception as e:
                self.logger.error(f"Ошибка при исправлении JSON с помощью языковой модели: {e}")

        self.logger.error(f"Не удалось обработать JSON" + (f" для агента {agent_type}" if agent_type else ""))
        return None

    def _process_dialog_response(self, json_str: str) -> str:
        """
        Обрабатывает текстовую часть ответа диалогового агента.
        """
        def escape_special_chars(s):
            """Экранирует специальные символы в JSON-строке, не затрагивая уже экранированные."""
            def replace_unescaped(match):
                char = match.group(1)
                if char == '\\':
                    return '\\\\'
                elif char == '"':
                    return '\\"'
                elif char == '\n':
                    return '\\n'
                elif char == '\r':
                    return '\\r'
                else:
                    return char

            # Паттерн для поиска неэкранированных спецсимволов
            pattern = r'(?<!\\)([\\\"\n\r])'
            return re.sub(pattern, replace_unescaped, s)

        # Ищем начало поля "response"
        start = json_str.find('"response"')
        if start == -1:
            self.logger.warning("Поле 'response' не найдено в JSON")
            return json_str

        # Находим открывающую кавычку содержимого "response"
        content_start = json_str.find(':', start)
        if content_start == -1:
            self.logger.warning("Не найдено начало содержимого 'response'")
            return json_str
        content_start = json_str.find('"', content_start)
        if content_start == -1:
            self.logger.warning("Не найдена открывающая кавычка содержимого 'response'")
            return json_str

        # Ищем конец "response" по паттерну ',"state"' или '},"state"' и их вариациям
        end_patterns = [r',\s*"state"', r'}\s*,\s*"state"']
        content_end = -1
        for pattern in end_patterns:
            match = re.search(pattern, json_str[content_start:])
            if match:
                content_end = content_start + match.start()
                break

        if content_end == -1:
            self.logger.warning("Не найден конец содержимого 'response'")
            return json_str

        # Извлекаем содержимое "response"
        content = json_str[content_start + 1:content_end - 1]  # -1 чтобы не включать закрывающую кавычку

        # Экранируем содержимое
        escaped_content = escape_special_chars(content)

        # Заменяем оригинальное содержимое на экранированное
        processed_json = json_str[:content_start + 1] + escaped_content + json_str[content_end - 1:]

        return processed_json



    def _preprocess_json(self, raw_string: str) -> str:
        """
        Предварительная обработка строки JSON, для устранения распространенных проблем.
        Предотвращает двойное экранирование.

        Args:
            raw_string (str): Исходная строка JSON.

        Returns:
            str: Предобработанная строка JSON.
        """
        try:
            # Удаление BOM, если он присутствует
            clean_string = raw_string.lstrip('\ufeff')

            # Удаление возможных начальных и конечных пробелов
            clean_string = clean_string.strip()

            # Находим начало структуры JSON
            start_patterns = ['"response":', '"summary":', '{']
            start_index = next((clean_string.find(pattern) for pattern in start_patterns if clean_string.find(pattern) != -1), 0)
            clean_string = clean_string[start_index:]

            # Находим конец структуры JSON
            end_patterns = [']}', '}']
            end_index = next((clean_string.rfind(pattern) for pattern in end_patterns if clean_string.rfind(pattern) != -1), len(clean_string))
            clean_string = clean_string[:end_index + 1]  # +1 чтобы включить закрывающую скобку

            # Обработка строковых значений
            def process_string_content(content: str) -> str:
                # Заменяем переносы строк на \n только если они еще не экранированы
                content = re.sub(r'(?<!\\)\n', r'\\n', content)
                content = re.sub(r'(?<!\\)\r', r'\\r', content)
                
                # Экранируем обратные слеши, которые не являются частью escape-последовательностей
                content = re.sub(r'(?<!\\)\\(?!["\\/bfnrtu])', r'\\\\', content)
                
                # Экранируем кавычки, только если они еще не экранированы
                content = re.sub(r'(?<!\\)"', r'\\"', content)
                
                return content

            # Обрабатываем строковые значения, сохраняя структуру
            processed_string = ""
            in_string = False
            escape = False
            for char in clean_string:
                if char == '"' and not escape:
                    in_string = not in_string
                    processed_string += char
                elif in_string:
                    processed_string += process_string_content(char)
                else:
                    processed_string += char
                escape = char == '\\' and not escape

            # Исправление отсутствующих запятых между элементами
            processed_string = re.sub(r'}\s*{', '},{', processed_string)
            processed_string = re.sub(r'"\s*"', '","', processed_string)
            processed_string = re.sub(r']\s*\[', '],[', processed_string)

            # Исправление отсутствующих кавычек вокруг ключей
            processed_string = re.sub(r'([{,]\s*)(\w+)(:)', r'\1"\2"\3', processed_string)

            # Удаление лишних запятых
            processed_string = re.sub(r',\s*([}\]])', r'\1', processed_string)

            # Исправление некорректных значений
            processed_string = processed_string.replace('true', 'true').replace('false', 'false').replace('null', 'null')

            # Убеждаемся, что строка начинается и заканчивается правильно
            if not processed_string.startswith('{'):
                processed_string = '{' + processed_string
            if not processed_string.endswith('}'):
                processed_string = processed_string + '}'

            return processed_string
        except Exception as e:
            self.logger.error(f"Ошибка при предобработке строки JSON: {e}")
            # В случае ошибки возвращаем исходную строку, но применяем базовые исправления
            return self._basic_json_like_string_fixes(raw_string)

    def _basic_json_like_string_fixes(self, raw_string: str) -> str:
        """
        Применяет базовые исправления к строке JSON, в случае ошибок в основном методе предобработки.

        Args:
            raw_string (str): Исходная строка JSON.

        Returns:
            str: Строка JSON, с базовыми исправлениями.
        """
        # Удаление BOM и пробелов
        clean_string = raw_string.lstrip('\ufeff').strip()

        # Базовые исправления структуры
        if not clean_string.startswith('{'):
            clean_string = '{' + clean_string
        if not clean_string.endswith('}'):
            clean_string = clean_string + '}'

        # Исправление наиболее распространенных проблем с форматированием
        clean_string = re.sub(r'}\s*{', '},{', clean_string)
        clean_string = re.sub(r'"\s*"', '","', clean_string)
        clean_string = re.sub(r']\s*\[', '],[', clean_string)
        clean_string = re.sub(r',\s*([}\]])', r'\1', clean_string)

        return clean_string

    async def _fix_json_with_llm(self, invalid_json: str, agent_type: str) -> Optional[Dict[str, Any]]:
        """
        Исправляет JSON с помощью языковой модели.

        Args:
            invalid_json (str): Некорректный JSON.
            agent_type (str): Тип агента для выбора соответствующего промпта.

        Returns:
            Optional[Dict[str, Any]]: Исправленный JSON или None, если не удалось исправить.
        """
        prompt = self.fix_prompts[agent_type]
        messages = [
            {"role": "system", "content": prompt},
            {"role": "user", "content": f"Исправьте следующий JSON:\n\n{invalid_json}"}
        ]

        try:
            corrected_json_str = await self.llm_client.get_completion(messages)
            self.logger.debug(f"Исправленный JSON от LLM:\n{corrected_json_str}")
            
            # Пытаемся распарсить исправленный JSON
            corrected_json = json.loads(corrected_json_str)
            return corrected_json
        except json.JSONDecodeError as e:
            self.logger.error(f"Не удалось распарсить исправленный JSON от LLM: {e}")
            return None
        except Exception as e:
            self.logger.error(f"Ошибка при исправлении JSON с помощью LLM: {e}")
            return None

    async def log_fix(self, agent_type: str, original_json: str, fixed_json: str):
        """
        Логирует процесс исправления JSON.

        Args:
            agent_type (str): Тип агента.
            original_json (str): Исходный JSON.
            fixed_json (str): Исправленный JSON.
        """
        self.logger.info(f"Логирование исправления для агента типа {agent_type}")
        log_entry = {
            "agent_type": agent_type,
            "original_json": original_json,
            "fixed_json": fixed_json
        }
        log_file = os.path.join(self.config.LOG_DIR, f"fixer_{agent_type}.log")
        with open(log_file, "a", encoding="utf-8") as f:
            json.dump(log_entry, f, ensure_ascii=False, indent=2)
            f.write("\n")  # Добавляем перевод строки для разделения записей