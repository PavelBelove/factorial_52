# quantum_rpg_bot/agents/dialog_agent.py

import json
import logging
import asyncio
from typing import List, Dict, Callable, Optional, Union, Awaitable
from config import Config
from llm_clients.base_client import BaseLLMClient
from agents.fixer_agent import FixerAgent
from memory.context_builder import ContextBuilder

class DialogAgent:
    def __init__(self, config: Config, llm_client: BaseLLMClient, fixer_agent: FixerAgent, context_builder: ContextBuilder):
        self.logger = logging.getLogger(__name__)
        self.config = config
        self.llm_client = llm_client
        self.fixer_agent = fixer_agent
        self.context_builder = context_builder
        self.last_state = {}
        self.last_requested_quanta = []

    async def process(self, user_id: int, game_id: int, user_message: str, context: List[Dict], 
                    update_callback: Optional[Union[Callable[[], None], Callable[[], Awaitable[None]]]] = None) -> Dict[str, any]:
        self.logger.info(f"Начало обработки сообщения для пользователя {user_id}, игра {game_id}")
        
        if not user_message.strip():
            return {
                "response": "Пустое сообщение. Пожалуйста, напишите что-нибудь", 
                "state": self.last_state, 
                "requested_quanta": []
            }

        messages = await self._prepare_messages(user_id, game_id, user_message, context)

        messages.append({
            "role": "system", 
            "content": "Ответ должен быть строго в формате JSON, ты отвечаешь серверу."
        })

        try:
            self.logger.info(f"Отправка запроса к языковой модели для пользователя {user_id}, игра {game_id}")
            
            async def safe_update_callback():
                if update_callback:
                    try:
                        if asyncio.iscoroutinefunction(update_callback):
                            await update_callback()
                        else:
                            update_callback()
                    except Exception as e:
                        self.logger.error(f"Ошибка при выполнении update_callback: {e}")

            llm_response = await self.llm_client.get_completion(messages, safe_update_callback)
            
            self.logger.info(f"Сырой ответ ГМ (user_id: {user_id}, game_id: {game_id}):\n{llm_response}")

            # Используем новый метод для обеспечения корректной структуры
            corrected_response = self._ensure_valid_json_structure(llm_response)

            processed_response = await self.fixer_agent.process_and_fix_json(corrected_response, 'dialog')
            if processed_response:
                if isinstance(processed_response, dict):
                    self.last_state = processed_response.get('state', {})
                    self.last_requested_quanta = processed_response.get('requested_quanta', [])
                    self.logger.info(f"Получен обработанный ответ для пользователя {user_id}: {processed_response}")
                    return processed_response
                else:
                    self.logger.error(f"Неожиданный тип ответа: {type(processed_response)}")
                    raise ValueError("Неожиданный тип ответа от fixer_agent")
            else:
                raise ValueError("Не удалось обработать ответ от модели")
        
        except Exception as e:
            self.logger.error(f"Ошибка при обработке диалога для пользователя {user_id}, игра {game_id}: {e}")
            return {
                "response": "Извините, произошла ошибка при обработке вашего сообщения. Пожалуйста, повторите последнее действие.", 
                "state": self.last_state, 
                "requested_quanta": []
            }

    async def _prepare_messages(self, user_id: int, game_id: int, user_message: str, context: List[Dict]) -> List[Dict[str, str]]:
        """
        Подготовка сообщений для отправки языковой модели.

        Args:
            user_id (int): ID пользователя.
            game_id (int): ID игры.
            user_message (str): Сообщение пользователя.
            context (List[Dict]): Контекст диалога.

        Returns:
            List[Dict[str, str]]: Список сообщений для языковой модели.
        """
        messages = [
            {"role": "system", "content": self.config.ROLE_PROMPT},
            *context,
            {"role": "user", "content": user_message}
        ]
        return messages

    def get_last_state(self) -> Dict:
        """
        Возвращает последнее сохраненное состояние.

        Returns:
            Dict: Последнее состояние игры.
        """
        return self.last_state

    def get_last_requested_quanta(self) -> List[str]:
        """
        Возвращает список последних запрошенных квантов.

        Returns:
            List[str]: Список названий последних запрошенных квантов.
        """
        return self.last_requested_quanta
    
    def _ensure_valid_json_structure(self, raw_response: str) -> str:
        """
        Проверяет и корректирует структуру ответа модели, обеспечивая наличие всех необходимых полей.
        
        Args:
            raw_response (str): Исходный ответ языковой модели.
        
        Returns:
            str: Строка, похожая на JSON, с корректной структурой.
        """
        # Проверяем наличие ключевых полей
        has_response = '"response"' in raw_response
        has_state = '"state"' in raw_response
        has_requested_quanta = '"requested_quanta"' in raw_response
        
        if has_response and has_state and has_requested_quanta:
            # Все поля присутствуют, возвращаем исходный ответ
            return raw_response
        self.logger.info(f'Модель ответила не корректно, сырой текст ответа: {raw_response}')
        # Формируем новую структуру
        corrected_response = "{"
        
        # Добавляем поле response
        if has_response:
            response_start = raw_response.index('"response"')
            response_end = raw_response.find('"state"', response_start)
            if response_end == -1:
                response_end = raw_response.find('"requested_quanta"', response_start)
            if response_end == -1:
                response_end = len(raw_response)
            corrected_response += raw_response[response_start:response_end].rstrip(",")
        else:
            # Используем json.dumps для корректного экранирования
            corrected_response += f'"response": {json.dumps(raw_response)}'
        
        # Добавляем поле state
        if not has_state:
            corrected_response += f', "state": {json.dumps(self.last_state)}'
        else:
            state_start = raw_response.index('"state"')
            state_end = raw_response.find('"requested_quanta"', state_start)
            if state_end == -1:
                state_end = len(raw_response)
            corrected_response += ", " + raw_response[state_start:state_end].rstrip(",")
        
        # Добавляем поле requested_quanta
        if not has_requested_quanta:
            corrected_response += f', "requested_quanta": {json.dumps(self.last_requested_quanta)}'
        else:
            quanta_start = raw_response.index('"requested_quanta"')
            corrected_response += ", " + raw_response[quanta_start:]
        
        # Закрываем структуру
        if not corrected_response.rstrip().endswith("}"):
            corrected_response += "}"
        
        return corrected_response