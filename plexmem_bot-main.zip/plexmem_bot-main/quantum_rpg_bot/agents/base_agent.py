from abc import ABC, abstractmethod

class BaseAgent(ABC):
    """
    Базовый класс для всех агентов в системе.
    
    Этот класс определяет общий интерфейс для всех агентов и предоставляет
    базовую функциональность, которую можно переопределить в дочерних классах.
    """

    def __init__(self, config, gpt_client):
        """
        Инициализация базового агента.

        Args:
            config (Config): Объект конфигурации.
            gpt_client: Клиент для взаимодействия с GPT.
        """
        self.config = config
        self.gpt_client = gpt_client

    @abstractmethod
    async def process(self, context):
        """
        Абстрактный метод для обработки входных данных агентом.

        Этот метод должен быть реализован в каждом конкретном агенте.

        Args:
            context: Контекст для обработки (может варьироваться в зависимости от типа агента).

        Returns:
            Результат обработки (зависит от конкретного агента).
        """
        pass

    async def get_completion(self, messages):
        """
        Метод для получения ответа от GPT.

        Args:
            messages (list): Список сообщений для отправки GPT.

        Returns:
            str: Ответ от GPT.
        """
        return await self.gpt_client.get_completion(messages)