# quantum_rpg_bot/agents/summarizer_agent.py

import json
import logging
from typing import List, Dict, Any
from config import Config
from llm_clients.base_client import BaseLLMClient
from agents.fixer_agent import FixerAgent
from database import Database

class SummarizerAgent:
    def __init__(self, config: Config, llm_client: BaseLLMClient, fixer_agent: FixerAgent, database: Database):
        self.config = config
        self.llm_client = llm_client
        self.fixer_agent = fixer_agent
        self.db = database
        self.logger = logging.getLogger(__name__)
        self.last_summary = {}  # Хранение последнего успешного саммари
        self.context_manager = None  # Будет установлено позже

    def set_context_manager(self, context_manager):
        self.context_manager = context_manager

    async def process(self, game_id: int) -> Dict[str, Any]:
        """
        Обработка контекста и создание обновленного саммари и квантов.

        Args:
            game_id (int): ID игры.

        Returns:
            Dict[str, Any]: Словарь с обновленным саммари и квантами.
        """
        self.logger.info(f"Начало процесса суммаризации для игры {game_id}")
        
        raw_context = await self.context_manager.get_summarizer_context(game_id)
        
        # Преобразование контекста
        processed_context = []
        for item in raw_context:
            if item['role'] == 'assistant':
                processed_context.append({"source": "model", "content": item['content']})
            elif item['role'] == 'user':
                processed_context.append({"source": "player", "content": item['content']})
            else:
                processed_context.append(item)  # Сохраняем другие роли без изменений

        # Оборачиваем контекст в JSON
        context_json = json.dumps({
            "game_id": game_id,
            "narrative": processed_context
        }, ensure_ascii=False)

        messages = [
            {"role": "system", "content": self.config.CONTEXT_SUMMARIZATION_PROMPT},
            {"role": "user", "content": f"Проанализируйте следующий игровой контекст: {context_json}"}
        ]
        
        self.logger.debug(f"Контекст для Сума (game_id: {game_id}):\n{json.dumps(messages, ensure_ascii=False, indent=2)}")

        for attempt in range(3):  # Максимум 3 попытки
            try:
                summary_response = await self.llm_client.get_completion(messages)
                
                self.logger.debug(f"Сырой ответ Сума (попытка {attempt + 1}, game_id: {game_id}):\n{summary_response}")

                summary_data = await self.fixer_agent.process_and_fix_json(summary_response, 'summarizer')
                
                if summary_data is not None:
                    processed_summary = self._process_summary(summary_data)
                    await self.db.save_summary(game_id, json.dumps(processed_summary, ensure_ascii=False))
                    self.last_summary = processed_summary
                    self.logger.debug(f"Новое саммари успешно обработано и сохранено для игры {game_id} \n {processed_summary}")
                    return processed_summary
                else:
                    self.logger.warning(f"Не удалось обработать JSON от Summarizer для игры {game_id}, попытка {attempt + 1}")
            except Exception as e:
                self.logger.error(f"Ошибка при обработке суммаризации (попытка {attempt + 1}): {e}")

        self.logger.error(f"Не удалось получить корректное саммари после 3 попыток для игры {game_id}")
        return self.last_summary 


    async def _process_and_save_summary(self, game_id: int, summary_response: str):
        """
        Асинхронная обработка и сохранение саммари.

        Args:
            game_id (int): ID игры.
            summary_response (str): Ответ от языковой модели.
        """
        try:
            summary_data = await self.json_handler.process_json(summary_response, 'summarization')
            
            if summary_data is not None:
                processed_summary = self._process_summary(summary_data)
                await self.db.save_summary(game_id, processed_summary)
                self.last_summary = processed_summary  # Обновляем последнее успешное саммари
                print(f"Новое саммари успешно обработано и сохранено для игры {game_id}")
            else:
                print(f"Не удалось обработать JSON от Summarizer для игры {game_id}")
        except Exception as e:
            print(f"Ошибка при асинхронной обработке саммари: {e}")

    async def _prepare_messages(self, previous_summary: Dict[str, Any], context: List[Dict]) -> List[Dict[str, str]]:
        """
        Подготовка сообщений для отправки языковой модели.

        Args:
            previous_summary (Dict[str, Any]): Предыдущее саммари.
            context (List[Dict]): Список словарей с информацией о ходах диалога.

        Returns:
            List[Dict[str, str]]: Список сообщений для языковой модели.
        """
        messages = [
            {"role": "system", "content": self.config.CONTEXT_SUMMARIZATION_PROMPT},
            {"role": "user", "content": f"Предыдущее саммари:\n{previous_summary}\n\nНовые ходы диалога:"}
        ]

        for turn in context:
            messages.append({"role": "user", "content": turn['user_message']})
            messages.append({"role": "assistant", "content": turn['assistant_response']})

        return messages

    def _process_summary(self, summary_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Обработка данных саммари.

        Args:
            summary_data (Dict[str, Any]): Данные саммари от языковой модели.

        Returns:
            Dict[str, Any]: Обработанные данные саммари.
        """
        processed_summary = {
            "summary": summary_data.get("summary", {}),
            "quanta": []
        }

        for quantum in summary_data.get("quanta", []):
            processed_quantum = {
                "name": quantum.get("name", ""),
                "type": quantum.get("type", ""),
                "attention": quantum.get("attention", 0),
                "summary": quantum.get("summary", ""),
                "related_quanta": quantum.get("related_quanta", {}),
                "details": quantum.get("details", {})
            }
            processed_summary["quanta"].append(processed_quantum)

        return processed_summary
    
    def should_summarize(self, turn_number: int) -> bool:
        """
        Проверка необходимости выполнения суммаризации.

        Args:
            turn_number (int): Номер текущего хода.

        Returns:
            bool: True, если нужно выполнить суммаризацию, иначе False.
        """
        should_sum = turn_number % self.config.SUMMARIZE_INTERVAL == 0 and turn_number > self.config.MAX_CONTEXT_TURNS
        self.logger.debug(f"Проверка необходимости суммаризации: turn_number={turn_number}, should_summarize={should_sum}")
        return should_sum