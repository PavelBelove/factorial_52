# quantum_rpg_bot/utils/async_utils.py
import asyncio
from functools import wraps

def async_retry(max_retries=3, base_delay=1):
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            for attempt in range(max_retries):
                try:
                    return await func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_retries - 1:
                        raise
                    delay = base_delay * (2 ** attempt)
                    print(f"Попытка {attempt + 1} не удалась. Повтор через {delay} секунд.")
                    await asyncio.sleep(delay)
        return wrapper
    return decorator