import random
from typing import List, Tuple

def generate_dice_rolls(num_pairs: int) -> List[Tuple[int, int, int, str]]:
    """
    Генерирует заданное количество пар бросков двух костей.
    
    Args:
        num_pairs (int): Количество пар бросков для генерации.
    
    Returns:
        List[Tuple[int, int, int, str]]: Список кортежей, каждый содержит
        (бросок1, бросок2, сумма, результат).
    """
    results = []
    for _ in range(num_pairs):
        roll1 = random.randint(1, 6)
        roll2 = random.randint(1, 6)
        total = roll1 + roll2
        
        if total == 2:
            result = "Критическая неудача"
        elif 3 <= total <= 5:
            result = "Неудача"
        elif 6 <= total <= 8:
            result = "Частичный успех"
        elif 9 <= total <= 11:
            result = "Успех"
        else:  # total == 12
            result = "Критический успех"
        
        results.append((roll1, roll2, total, result))
    
    return results

def format_dice_rolls(rolls: List[Tuple[int, int, int, str]]) -> List[str]:
    """
    Форматирует результаты бросков для использования ГМ.
    
    Args:
        rolls (List[Tuple[int, int, int, str]]): Список результатов бросков.
    
    Returns:
        List[str]: Список отформатированных строк с результатами бросков.
    """
    return [f"{roll1} + {roll2} = {total}: {result}" for roll1, roll2, total, result in rolls]
