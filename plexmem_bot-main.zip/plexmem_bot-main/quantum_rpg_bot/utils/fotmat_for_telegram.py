import re

def format_response_for_telegram(response: str) -> str:
    """
    Форматирует ответ для корректного отображения в Telegram.
    """
    # Шаг 1: Удаление маркеров парсинга
    response = re.sub(r'^<<<|>>>$', '', response.strip())

    # Шаг 2: Замена двойных обратных слэшей на одинарные
    response = response.replace('\\\\', '\\')

    # Шаг 3: Обработка переносов строк
    response = response.replace('\\n', '\n')
    response = re.sub(r'\n{3,}', '\n\n', response)

    # Шаг 4: Экранирование специальных символов Markdown
    special_chars = '_*[]()~`>#+=|{}.!-'
    for char in special_chars:
        response = response.replace(char, '\\' + char)

    # Шаг 5: Восстановление форматирования для жирного текста и списков
    response = re.sub(r'\\\*\\\*(.+?)\\\*\\\*', r'*\1*', response)
    response = re.sub(r'^•\\s(.+)$', r'• \1', response, flags=re.MULTILINE)

    # Шаг 6: Ограничение длины сообщения
    if len(response) > 4096:
        response = response[:4093] + '...'

    return response