import requests
import json
import time

def check_api_key(api_key):
    url = "https://api.openai.com/v1/embeddings"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    data = {
        "input": "Hello, World!",
        "model": "text-embedding-ada-002"
    }
    
    try:
        response = requests.post(url, headers=headers, data=json.dumps(data))
        if response.status_code == 200:
            print(f"Key is valid and working: {api_key}")
            print(f"Response: {response.status_code} {response.reason}")
        else:
            print(f"Key is invalid or there's an issue: {api_key}")
            print(f"Error: {response.status_code} {response.reason}")
            print(f"Error message: {response.json().get('error', {}).get('message', 'Unknown error')}")
    except Exception as e:
        print(f"Error occurred while checking key {api_key}: {str(e)}")

# List of API keys to check
api_keys = [
    "sk-svcacct-HU_4U4jRoSq6id7rVA6fUSEsdrna-cH5ATu2QWL2GUXuNbVMI2vcFCO8TffT3BlbkFJJS-PG84iR_JOoUMXbX7Rcb-UsaS7v2VxMbD-u4kOyX7AdtGqN39YwnKg5AA",
    "sk-svcacct-vWKNC94kE1X_TLG456lhWU_NbpLPtizRgnkjfJPPyBKvtg_Qp02BlxhJ24sT3BlbkFJt_4pmtT2IxIbIbsQhF3__v7VGGhBzi-qJF4BjFMvIneSKhgws2K0pJ3UhAA",
    "sk-svcacct-7iwmLYVUtbFX7N8mzEgrP_peYX14QhuAPUE71OL9QU2DoQ_xro3OBlgp62MT3BlbkFJpdOHPqzy9uxJrfVZwaWDi1b-HmfWoB8EwEFPxmpE_bm8M9cOq-txTOvHrAA",
    "sk-svcacct-4KUY9YXGnBE1R-LzwogN318hQ9PjhuqShYQLivV4yY4V_1rg3vA--NpCuklT3BlbkFJZR85-dTgeA8cAdFc7TjynfVrGrkbrGS2zFT3WtytRDdR8nEPT9_KrZGPkAA",
    "sk-svcacct-X1KHYTHg4IOdW5gHOfBswjSaqKKLQeemVcwIpCQrt_aT0J8gONWau4R1_PzT3BlbkFJJ14Lb9w7cSbVAqgnL2blXDOwjdgVENSKRYzWW-zibFC3Wa5qxJXTnQ_bxAA",
    "sk-svcacct-Hk4ch7gvA2V2R_81gi8AvfynEB25krAFfXKIzB5Hlj1z1vJMCIvqKsqNzjTT3BlbkFJfQ9zQGsP4Dxg-JN0sYAWNNQ2_o2TnEm_4NFWreXHOraSS9OeKM9iG7kWDAA",
    "sk-svcacct-kSHjl1ZhW7WBxU--b_OP06tMaq-teFUcq4J-nRUwcejQjOZi1npKGUYcrPdT3BlbkFJ7yDnAQMJz_a_y4dwdyg5u9cE7gNP90VgVvLMAYy8lXIvgJyhTqCi9y004AA",
    "sk-svcacct-5OLi-lita9RYzPsi9qLbPR2jOnYGSwT0RpGkWbmZAoek_qx4FtkazuGWBDIT3BlbkFJ5YRYoAhGNKyO5_v37M7x4lwUseeTeYK4GA7hP3BEkEm1MljaWsQiBP3o3AA",
    "sk-svcacct-kenz6EuDXwbbxCapKSCPEyKZkp0Cj5aXCaxeVhhNhrBazsaAPVsQLpgVHKiT3BlbkFJRKBe_z6qbJYdbnxVmKC7-qyL01bEh5K6h9N9egb6kIDDS8rbofHdcrBA1jAA",
    "sk-svcacct-q43NmwmYVdnWgpLMCyGKM1i4h-qWlHmxclGYyoviH_7BwS29wowf7d2pDqkT3BlbkFJ6F0ggzWUzoIuKgbXy7X12PdD9zEwv8Tic-bvkWfeARMbbnhLA-kYPr9tj_gA"
]

# Check each API key
for api_key in api_keys:
    check_api_key(api_key.strip())
    print("\n")  # Add a blank line between checks for readability
    time.sleep(1)  # Add a small delay between requests to avoid rate limiting