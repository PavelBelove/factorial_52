# quantum_rpg_bot/__main__.py

import logging
from aiogram import Bot, Dispatcher, executor, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from config import Config
from database import Database
from memory.quantum import QuantumMemory
from memory.context_builder import ContextBuilder
from memory.context_manager import ContextManager
from memory.session_manager import SessionManager
from agents.dialog_agent import DialogAgent
from agents.summarizer_agent import SummarizerAgent
from agents.fixer_agent import FixerAgent
from handlers.command_handlers import setup_command_handlers
from handlers.menu_handlers import GameMenuStates, setup_menu_handlers
from handlers.message_handlers import setup_message_handlers
from handlers.settings_handlers import setup_settings_handlers 


# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def setup_handlers(dp: Dispatcher, config: Config, database: Database, dialog_agent: DialogAgent, context_manager: ContextManager, session_manager: SessionManager):
    """
    Настройка обработчиков для бота.

    Args:
        dp (Dispatcher): Диспетчер бота.
        config (Config): Объект конфигурации.
        database (Database): Объект базы данных.
        dialog_agent (DialogAgent): Агент диалога.
        context_manager (ContextManager): Менеджер контекста.
        session_manager (SessionManager): Менеджер сессий.
    """
    setup_command_handlers(dp, config, database)
    setup_menu_handlers(dp, config, database, session_manager)
    setup_settings_handlers(dp)
    setup_message_handlers(dp, config, database, dialog_agent, context_manager)

async def on_startup(dp: Dispatcher):
    """
    Действия при запуске бота.

    Args:
        dp (Dispatcher): Диспетчер бота.
    """
    logger.info("Запуск бота")
    await database.initialize()
    setup_handlers(dp, config, database, dialog_agent, context_manager, session_manager)
    await restore_user_states(dp)

async def restore_user_states(dp: Dispatcher):
    """
    Восстанавливает состояния пользователей из базы данных.

    Args:
        dp (Dispatcher): Диспетчер бота.
    """
    users = await database.get_all_active_users()
    for user in users:
        user_state = await database.get_user_state(user['id'])
        if user_state:
            await dp.storage.set_state(user=user['id'], state=GameMenuStates.IN_GAME.state)
            await dp.storage.set_data(user=user['id'], data={'current_game_id': user_state['current_game_id']})
    logger.info(f"Восстановлено состояний: {len(users)}")

if __name__ == "__main__":
    # Инициализация основных компонентов
    config = Config()
    database = Database(config.DB_PATH)
    llm_client = config.get_llm_client()
    quantum_memory = QuantumMemory(database)
    context_builder = ContextBuilder(config, quantum_memory, database)

    # Инициализация агентов
    fixer_agent = FixerAgent(config, llm_client)
    context_manager = ContextManager(config, quantum_memory, context_builder, database)
    summarizer_agent = SummarizerAgent(config, llm_client, fixer_agent, database)
    dialog_agent = DialogAgent(config, llm_client, fixer_agent, context_builder)

    # Устанавливаем связи между объектами
    context_manager.set_summarizer_agent(summarizer_agent)
    summarizer_agent.set_context_manager(context_manager)

    # Менеджер сессий
    session_manager = SessionManager(config, database, context_manager, dialog_agent)

    # Настройка бота
    bot = Bot(token=config.TELEGRAM_TOKEN)
    storage = MemoryStorage()
    dp = Dispatcher(bot, storage=storage)

    # Установка зависимостей для бота
    bot['config'] = config
    bot['database'] = database
    bot['context_manager'] = context_manager
    bot['dialog_agent'] = dialog_agent
    bot['fixer_agent'] = fixer_agent
    bot['session_manager'] = session_manager

    # Запуск бота
    executor.start_polling(dp, on_startup=on_startup, skip_updates=True, allowed_updates=types.AllowedUpdates.all())