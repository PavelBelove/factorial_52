# quantum_rpg_bot/handlers/settings_handlers.py

from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from handlers.menu_handlers import GameMenuStates
from database import Database
from config import Config
from utils.game_settings import GameSettings

async def show_settings_menu(callback_query: types.CallbackQuery, state: FSMContext):
    """Показывает главное меню настроек."""
    config = callback_query.bot.get('config')
    user_data = await state.get_data()
    language = user_data.get('language', config.DEFAULT_LANGUAGE)
    loc = config.get_localization(language)
    
    keyboard = InlineKeyboardMarkup(row_width=1)
    keyboard.add(InlineKeyboardButton(loc.get_settings_menu()["language"], callback_data="settings_language"))
    keyboard.add(InlineKeyboardButton(loc.get_settings_menu()["difficulty"], callback_data="settings_difficulty"))
    keyboard.add(InlineKeyboardButton(loc.get_settings_menu()["censorship"], callback_data="settings_censorship"))
    keyboard.add(InlineKeyboardButton(loc.get_settings_menu()["rules"], callback_data="show_rules"))
    keyboard.add(InlineKeyboardButton(loc.get_settings_menu()["feedback"], callback_data="show_feedback"))
    keyboard.add(InlineKeyboardButton(loc.get_back(), callback_data="back_to_main_menu"))

    await callback_query.message.edit_text(loc.get_settings_menu()["message"], reply_markup=keyboard)
    await GameMenuStates.SETTINGS_MENU.set()

async def show_language_settings(callback_query: types.CallbackQuery, state: FSMContext):
    """Показывает меню выбора языка."""
    config = callback_query.bot.get('config')
    user_data = await state.get_data()
    current_language = user_data.get('language', config.DEFAULT_LANGUAGE)
    loc = config.get_localization(current_language)

    keyboard = InlineKeyboardMarkup(row_width=2)
    for lang_code, lang_name in loc.get_available_languages().items():
        keyboard.add(InlineKeyboardButton(lang_name, callback_data=f"set_lang:{lang_code}"))
    keyboard.add(InlineKeyboardButton(loc.get_back(), callback_data="back_to_settings"))

    await callback_query.message.edit_text(loc.get_language_selection_message(), reply_markup=keyboard)
    await GameMenuStates.LANGUAGE_SETTINGS.set()

async def show_difficulty_settings(callback_query: types.CallbackQuery, state: FSMContext):
    """Показывает меню выбора уровня сложности."""
    config = callback_query.bot.get('config')
    user_data = await state.get_data()
    language = user_data.get('language', config.DEFAULT_LANGUAGE)
    loc = config.get_localization(language)

    keyboard = InlineKeyboardMarkup(row_width=1)
    for difficulty in GameSettings.get_difficulty_levels():
        keyboard.add(InlineKeyboardButton(loc.get_difficulty_level(difficulty), callback_data=f"set_difficulty:{difficulty}"))
    keyboard.add(InlineKeyboardButton(loc.get_back(), callback_data="back_to_settings"))

    await callback_query.message.edit_text(loc.get_difficulty_selection_message(), reply_markup=keyboard)
    await GameMenuStates.DIFFICULTY_SETTINGS.set()

async def show_censorship_settings(callback_query: types.CallbackQuery, state: FSMContext):
    """Показывает меню выбора уровня цензуры."""
    config = callback_query.bot.get('config')
    user_data = await state.get_data()
    language = user_data.get('language', config.DEFAULT_LANGUAGE)
    loc = config.get_localization(language)

    keyboard = InlineKeyboardMarkup(row_width=1)
    for censorship in GameSettings.get_censorship_levels():
        keyboard.add(InlineKeyboardButton(loc.get_censorship_level(censorship), callback_data=f"set_censorship:{censorship}"))
    keyboard.add(InlineKeyboardButton(loc.get_back(), callback_data="back_to_settings"))

    await callback_query.message.edit_text(loc.get_censorship_selection_message(), reply_markup=keyboard)
    await GameMenuStates.CENSORSHIP_SETTINGS.set()

async def show_rules(callback_query: types.CallbackQuery, state: FSMContext):
    """Показывает правила и механики игры."""
    config = callback_query.bot.get('config')
    user_data = await state.get_data()
    language = user_data.get('language', config.DEFAULT_LANGUAGE)
    loc = config.get_localization(language)

    rules_text = loc.get_rules()
    keyboard = InlineKeyboardMarkup().add(InlineKeyboardButton(loc.get_back(), callback_data="back_to_settings"))

    await callback_query.message.edit_text(rules_text, reply_markup=keyboard)

async def show_feedback(callback_query: types.CallbackQuery, state: FSMContext):
    """Показывает форму обратной связи."""
    config = callback_query.bot.get('config')
    user_data = await state.get_data()
    language = user_data.get('language', config.DEFAULT_LANGUAGE)
    loc = config.get_localization(language)

    feedback_text = loc.get_feedback_info()
    keyboard = InlineKeyboardMarkup().add(InlineKeyboardButton(loc.get_back(), callback_data="back_to_settings"))

    await callback_query.message.edit_text(feedback_text, reply_markup=keyboard)

async def process_setting_selection(callback_query: types.CallbackQuery, state: FSMContext):
    """Обрабатывает выбор настройки."""
    setting_type, value = callback_query.data.split(':')
    user_data = await state.get_data()
    game_id = user_data.get('current_game_id')

    if not game_id:
        await callback_query.answer("Ошибка: нет активной игры.")
        return

    config = callback_query.bot.get('config')
    database = callback_query.bot.get('database')

    current_state = await database.get_current_state(game_id) or {}
    
    if setting_type == 'set_lang':
        current_state['language'] = value
    elif setting_type == 'set_difficulty':
        current_state['difficulty'] = value
    elif setting_type == 'set_censorship':
        current_state['censorship'] = value

    await database.save_state(game_id, current_state)
    await state.update_data(language=current_state.get('language', config.DEFAULT_LANGUAGE))

    loc = config.get_localization(current_state.get('language', config.DEFAULT_LANGUAGE))
    await callback_query.answer(loc.get_setting_updated_message(setting_type.split('_')[1]))
    await show_settings_menu(callback_query, state)

async def back_to_settings(callback_query: types.CallbackQuery, state: FSMContext):
    """Возвращает пользователя в меню настроек."""
    await show_settings_menu(callback_query, state)

async def handle_adult_content(message: types.Message, state: FSMContext):
    """Обработчик секретной команды для включения взрослого контента."""
    user_data = await state.get_data()
    game_id = user_data.get('current_game_id')
    
    if not game_id:
        await message.edit_text("У вас нет активной игры. Начните новую игру, чтобы использовать эту команду.")
        return

    database = message.bot.get('database')
    current_state = await database.get_current_state(game_id) or {}
    current_state['adult_content'] = True
    await database.save_state(game_id, current_state)

    await message.answer("Режим без цензуры активирован. Будьте осторожны, контент может быть неподходящим для некоторых пользователей.")

def setup_settings_handlers(dp: Dispatcher):
    """Настраивает обработчики для меню настроек."""
    dp.register_callback_query_handler(show_settings_menu, lambda c: c.data == "settings", state="*")
    dp.register_callback_query_handler(show_language_settings, lambda c: c.data == "settings_language", state=GameMenuStates.SETTINGS_MENU)
    dp.register_callback_query_handler(show_difficulty_settings, lambda c: c.data == "settings_difficulty", state=GameMenuStates.SETTINGS_MENU)
    dp.register_callback_query_handler(show_censorship_settings, lambda c: c.data == "settings_censorship", state=GameMenuStates.SETTINGS_MENU)
    dp.register_message_handler(handle_adult_content, commands=['18plus'], state='*')
    dp.register_callback_query_handler(show_rules, lambda c: c.data == "show_rules", state=GameMenuStates.SETTINGS_MENU)
    dp.register_callback_query_handler(show_feedback, lambda c: c.data == "show_feedback", state=GameMenuStates.SETTINGS_MENU)
    dp.register_callback_query_handler(process_setting_selection, lambda c: c.data.startswith("set_"), state="*")
    dp.register_callback_query_handler(back_to_settings, lambda c: c.data == "back_to_settings", state="*")