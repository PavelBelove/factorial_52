# quantum_rpg_bot/handlers/command_handlers.py

"""
Модуль обработчиков команд для Quantum RPG Bot.

Этот модуль содержит обработчики для всех команд бота,
кроме команд, связанных с навигацией по меню (они находятся в menu_handlers.py).

Основные компоненты:
- Обработчики команд /help и /settings
- Функция настройки обработчиков команд
"""

import logging
from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from config import Config
from database import Database

logger = logging.getLogger(__name__)

async def help_command(message: types.Message, state: FSMContext, config: Config):
    """
    Обработчик команды /help.
    Отправляет пользователю справочную информацию о боте.

    Args:
        message (types.Message): Входящее сообщение.
        state (FSMContext): Текущее состояние FSM.
        config (Config): Конфигурация бота.
    """
    user_data = await state.get_data()
    language = user_data.get('language', config.DEFAULT_LANGUAGE)
    loc = config.get_localization(language)
    
    help_text = loc.get_help_message()
    await message.answer(help_text)

async def settings_command(message: types.Message, state: FSMContext, config: Config):
    """
    Обработчик команды /settings.
    Отправляет пользователю меню настроек (пока не реализовано).

    Args:
        message (types.Message): Входящее сообщение.
        state (FSMContext): Текущее состояние FSM.
        config (Config): Конфигурация бота.
    """
    user_data = await state.get_data()
    language = user_data.get('language', config.DEFAULT_LANGUAGE)
    loc = config.get_localization(language)
    
    settings_text = loc.get_settings_message()
    await message.answer(settings_text)

def setup_command_handlers(dp: Dispatcher, config: Config, database: Database):
    """
    Настраивает обработчики команд для бота.

    Args:
        dp (Dispatcher): Диспетчер бота.
        config (Config): Конфигурация бота.
        database (Database): Объект для работы с базой данных.
    """
    dp.register_message_handler(lambda message, state: help_command(message, state, config), commands=['help'])
    dp.register_message_handler(lambda message, state: settings_command(message, state, config), commands=['settings'])

    logger.info("Обработчики команд успешно настроены")