# quantum_rpg_bot/handlers/menu_handlers.py

"""
Модуль обработчиков меню для Quantum RPG Bot.

Этот модуль содержит все обработчики, связанные с навигацией по меню бота,
включая выбор языка, создание новой игры, сохранение и загрузку игр.
"""


import logging
from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from database import Database
from datetime import datetime
from config import Config
from memory.session_manager import SessionManager
from utils.fotmat_for_telegram import format_response_for_telegram

# Настройка логирования
logger = logging.getLogger(__name__)

# Определение состояний для FSM
class GameMenuStates(StatesGroup):
    LANGUAGE_SELECTION = State()
    MAIN_MENU = State()
    WORLD_SELECTION = State()
    WORLD_DESCRIPTION = State()
    SAVE_GAME = State()
    LOAD_GAME = State()
    IN_GAME = State()
    SETTINGS_MENU = State()
    LANGUAGE_SETTINGS = State()
    DIFFICULTY_SETTINGS = State()
    CENSORSHIP_SETTINGS = State()

async def show_language_selection(message: types.Message, state: FSMContext):
    """
    Показывает главное меню существующим пользователям или меню выбора языка новым.
    """
    config = message.bot.get('config')
    database = message.bot.get('database')
    user_id = message.from_user.id

    user_exists = await database.user_exists(user_id)
    if user_exists:
        await show_main_menu(message, state)
    else:
        logger.info(f"Показываем выбор языка для нового пользователя {user_id}")
        await GameMenuStates.LANGUAGE_SELECTION.set()
        keyboard = InlineKeyboardMarkup()
        default_loc = config.get_localization(config.DEFAULT_LANGUAGE)
        for lang_code, lang_name in default_loc.get_available_languages().items():
            keyboard.add(InlineKeyboardButton(lang_name, callback_data=f"set_lang:{lang_code}"))
        
        text = default_loc.get_language_selection_message()
        await message.answer(text, reply_markup=keyboard)

async def show_main_menu(message: types.Message, state: FSMContext):
    """
    Показывает главное меню игры.

    Args:
        message (types.Message): Сообщение пользователя.
        state (FSMContext): Текущее состояние FSM.
    """
    config = message.bot.get('config')
    user_data = await state.get_data()
    language = user_data.get('language', config.DEFAULT_LANGUAGE)
    loc = config.get_localization(language)
    menu = loc.get_main_menu()

    keyboard = InlineKeyboardMarkup()

        # Добавляем кнопку "Продолжить игру", если есть активная игра
    if user_data.get('current_game_id'):
        keyboard.add(InlineKeyboardButton(menu["continue_game"], callback_data="continue_game"))

    keyboard.add(InlineKeyboardButton(menu["new_game"], callback_data="new_game"))
    keyboard.add(InlineKeyboardButton(menu["load_game"], callback_data="load_game"))
    keyboard.add(InlineKeyboardButton(menu["save_game"], callback_data="save_game"))
    keyboard.add(InlineKeyboardButton(menu["settings"], callback_data="settings"))

    # Используем edit_text, если это callback_query, иначе отправляем новое сообщение
    if isinstance(message, types.CallbackQuery):
        await message.message.edit_text(menu["message"], reply_markup=keyboard)
    else:
        await message.answer(menu["message"], reply_markup=keyboard)
    
    await GameMenuStates.MAIN_MENU.set()

async def continue_game(callback_query: types.CallbackQuery, state: FSMContext):
    """Продолжает текущую игру."""
    user_data = await state.get_data()
    game_id = user_data.get('current_game_id')
    
    if game_id:
        await GameMenuStates.IN_GAME.set()
        await callback_query.message.edit_text(loc.get_continue_game_message)
        # Здесь нужно добавить логику для продолжения игры, например, вызов dialog_agent
    else:
        config = callback_query.bot.get('config')
        loc = config.get_localization(user_data.get('language', config.DEFAULT_LANGUAGE))
        await callback_query.edit_text(loc.get_no_active_game_message())

async def show_world_selection(message: types.Message, state: FSMContext):
    """
    Показывает меню выбора мира для новой игры.

    Args:
        message (types.Message): Сообщение пользователя.
        state (FSMContext): Контекст состояния FSM.
    """
    config = message.bot.get('config')
    user_data = await state.get_data()
    language = user_data.get('language', config.DEFAULT_LANGUAGE)
    loc = config.get_localization(language)

    keyboard = InlineKeyboardMarkup(row_width=2)
    world_buttons = loc.get_world_buttons()
    for world_id, world_name in world_buttons.items():
        keyboard.add(InlineKeyboardButton(text=world_name, callback_data=f"select_world:{world_id}"))

    keyboard.add(InlineKeyboardButton(loc.get_back(), callback_data="back_to_main_menu"))

    await message.edit_text(loc.get_world_selection_message(), reply_markup=keyboard)
    await GameMenuStates.WORLD_SELECTION.set()

async def process_world_selection(callback_query: types.CallbackQuery, state: FSMContext):
    """
    Обработчик выбора мира.
    Показывает описание выбранного мира и кнопки для начала игры.

    Args:
        callback_query (types.CallbackQuery): Callback-запрос.
        state (FSMContext): Контекст состояния FSM.
    """
    config = callback_query.bot.get('config')
    user_data = await state.get_data()
    language = user_data.get('language', config.DEFAULT_LANGUAGE)
    loc = config.get_localization(language)

    world_id = callback_query.data.split(':')[1]
    world_descriptions = loc.get_world_descriptions()
    world_description = world_descriptions.get(world_id, "Описание мира не найдено.")
    world_name = loc.get_world_buttons().get(world_id, world_id)

    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton(text=loc.get_back(), callback_data="back_to_worlds"))
    keyboard.add(InlineKeyboardButton(text=loc.get_start_game(), callback_data=f"start_game:{world_id}"))

    await callback_query.message.edit_text(f"{world_name}\n\n{world_description}", reply_markup=keyboard)
    await GameMenuStates.WORLD_DESCRIPTION.set()

async def start_new_game(callback_query: types.CallbackQuery, state: FSMContext):
    """
    Обработчик начала новой игры.
    """
    session_manager = callback_query.bot.get('session_manager')
    config = callback_query.bot.get('config')
    
    user_id = callback_query.from_user.id
    world_id = callback_query.data.split(':')[1]
    
    user_data = await state.get_data()
    language = user_data.get('language', config.DEFAULT_LANGUAGE)
    loc = config.get_localization(language)
    
    try:
        # Создание новой игры через SessionManager
        game_info = await session_manager.create_new_game(user_id, world_id, language)
        
        # Отправка сообщения о начале создания игры
        await callback_query.message.edit_text(loc.get_game_started_message(game_info['slot']))
        
        # Получение и обработка начального сообщения
        initial_message = await session_manager.get_initial_message(user_id, game_info['id'], language)
        response = await session_manager.process_initial_message(user_id, game_info['id'], initial_message)
        
        # Форматирование ответа для Telegram
        formatted_response = format_response_for_telegram(response)
        logger.info(f"Форматированное сообщение для телеги {formatted_response}")
        
        # Отправка отформатированного ответа ГМ
        await callback_query.message.answer(formatted_response, parse_mode='MarkdownV2')
        
        # Переход в состояние игры
        await GameMenuStates.IN_GAME.set()
        await state.update_data(current_game_id=game_info['id'])
    except Exception as e:
        logger.error(f"Ошибка при создании новой игры: {e}")
        await callback_query.message.edit_text(loc.get_error_message())
        await show_main_menu(callback_query.message, state)

async def show_save_slots(callback_query: types.CallbackQuery, state: FSMContext):
    """
    Показывает меню выбора слота для сохранения игры.
    """
    config = callback_query.bot.get('config')
    session_manager = callback_query.bot.get('session_manager')
    user_id = callback_query.from_user.id
    user_data = await state.get_data()
    language = user_data.get('language', config.DEFAULT_LANGUAGE)
    loc = config.get_localization(language)
    
    user_games = await session_manager.get_user_games(user_id)

    keyboard = InlineKeyboardMarkup(row_width=1)
    world_buttons = loc.get_world_buttons()
    for game in user_games:
        world_name = world_buttons.get(game['world_id'], game['world_id'])
        saved_at = datetime.strptime(game['saved_at'], "%Y-%m-%d %H:%M:%S")
        slot_text = f"{world_name} ({saved_at.strftime('%m-%d %H:%M')})"
        keyboard.add(InlineKeyboardButton(slot_text, callback_data=f"save_to_slot:{game['id']}"))
    
    empty_slots = set(range(1, 6)) - set(game['slot'] for game in user_games)
    for slot in empty_slots:
        slot_text = f"{loc.get_save_game()['slot'].format(slot)}: {loc.get_save_game()['empty']}"
        keyboard.add(InlineKeyboardButton(slot_text, callback_data=f"save_to_slot:{slot}"))

    keyboard.add(InlineKeyboardButton(loc.get_back(), callback_data="back_to_main_menu"))

    await callback_query.message.edit_text(loc.get_save_game()["message"], reply_markup=keyboard)
    await GameMenuStates.SAVE_GAME.set()

async def save_game_to_slot(callback_query: types.CallbackQuery, state: FSMContext):
    """
    Сохраняет игру в выбранный слот.
    """
    session_manager = callback_query.bot.get('session_manager')
    config = callback_query.bot.get('config')
    
    user_id = callback_query.from_user.id
    slot = int(callback_query.data.split(':')[1])
    
    user_data = await state.get_data()
    language = user_data.get('language', config.DEFAULT_LANGUAGE)
    loc = config.get_localization(language)
    
    current_game_id = user_data.get('current_game_id')
    if not current_game_id:
        await callback_query.edit_text(loc.get_error_messages()["no_active_game"], show_alert=True)
        return
    
    try:
        success = await session_manager.save_game(user_id, current_game_id, slot)
        if success:
            await callback_query.answedit_texter(loc.get_confirmation_messages()["save_success"].format(slot))
            
            # Обновляем информацию о сохраненных играх
            await session_manager.update_saved_games(user_id)
        else:
            raise Exception("Failed to save game")
    except Exception as e:
        logger.error(f"Ошибка при сохранении игры: {e}")
        await callback_query.answer(loc.get_error_messages()["save_error"], show_alert=True)
    
    await show_main_menu(callback_query.message, state)

async def show_load_slots(callback_query: types.CallbackQuery, state: FSMContext):
    """
    Показывает меню выбора слота для загрузки игры.
    """
    config = callback_query.bot.get('config')
    session_manager = callback_query.bot.get('session_manager')
    user_id = callback_query.from_user.id
    user_data = await state.get_data()
    language = user_data.get('language', config.DEFAULT_LANGUAGE)
    loc = config.get_localization(language)
    
    user_games = await session_manager.get_user_games(user_id)

    if not user_games:
        await callback_query.edit_text(loc.get_load_game()["no_saves"], show_alert=True)
        return

    keyboard = InlineKeyboardMarkup(row_width=1)
    for game in user_games:
        slot_text = f"{loc.get_load_game()['slot'].format(game['slot'])}: {game['world_id']} ({game['saved_at']})"
        keyboard.add(InlineKeyboardButton(slot_text, callback_data=f"load_from_slot:{game['id']}"))

    keyboard.add(InlineKeyboardButton(loc.get_back(), callback_data="back_to_main_menu"))

    await callback_query.message.edit_text(loc.get_load_game()["message"], reply_markup=keyboard)
    await GameMenuStates.LOAD_GAME.set()

async def load_game_from_slot(callback_query: types.CallbackQuery, state: FSMContext):
    """
    Загружает игру из выбранного слота.
    """
    session_manager = callback_query.bot.get('session_manager')
    config = callback_query.bot.get('config')
    
    user_id = callback_query.from_user.id
    game_id = int(callback_query.data.split(':')[1])
    
    user_data = await state.get_data()
    language = user_data.get('language', config.DEFAULT_LANGUAGE)
    loc = config.get_localization(language)
    
    try:
        game_data = await session_manager.load_game(user_id, game_id)
        if game_data:
            await state.update_data(current_game_id=game_id)
            
            await callback_query.edit_text(loc.get_confirmation_messages()["load_success"].format(game_data['slot']))
            await GameMenuStates.IN_GAME.set()
            
            # Получаем последние ходы для напоминания контекста
            recent_turns = await session_manager.get_recent_turns(game_id)
            if recent_turns:
                await callback_query.message.answer(loc.get_load_game().get('context_reminder', "Последние ходы:"))
                for turn in recent_turns:
                    await callback_query.message.answer(f"{loc.get_load_game()['player']}: {turn['user_message']}")
                    await callback_query.message.answer(f"{loc.get_load_game()['assistant']}: {turn['assistant_response']}")
            else:
                await callback_query.message.answer(loc.get_load_game().get('no_previous_turns', "Это новая игра. Начните свое приключение!"))
        else:
            raise ValueError("Game data not found")
    except Exception as e:
        logger.error(f"Ошибка при загрузке игры: {e}")
        await callback_query.answer(loc.get_error_messages()["load_error"], show_alert=True)
        await show_main_menu(callback_query.message, state)

async def handle_in_game_message(message: types.Message, state: FSMContext):
    """Обрабатывает текстовые сообщения в главном меню."""
    user_data = await state.get_data()
    if user_data.get('current_game_id'):
        await GameMenuStates.IN_GAME.set()
        # Здесь нужно добавить логику обработки сообщения в игре, например, вызов dialog_agent
        await message.answer(loc.get_no_active_game_message)
    else:
        config = message.bot.get('config')
        loc = config.get_localization(user_data.get('language', config.DEFAULT_LANGUAGE))
        await message.answer(loc.get_no_active_game_message())
        await show_main_menu(message, state)

# Дополнительные обработчики

async def set_language_handler(callback_query: types.CallbackQuery, state: FSMContext):
    """
    Обработчик выбора языка.
    """
    config = callback_query.bot.get('config')
    lang_code = callback_query.data.split(':')[1]
    await state.update_data(language=lang_code)
    loc = config.get_localization(lang_code)
    await callback_query.edit_text(loc.get_start_message())
    await show_world_selection(callback_query.message, state)

async def change_language_handler(callback_query: types.CallbackQuery, state: FSMContext):
    """
    Обработчик кнопки смены языка.
    """
    await show_language_selection(callback_query.message)

async def new_game_handler(callback_query: types.CallbackQuery, state: FSMContext):
    """
    Обработчик кнопки "Новая игра".
    """
    await show_world_selection(callback_query.message, state)


async def back_to_main_menu(callback_query: types.CallbackQuery, state: FSMContext):
    """
    Обработчик кнопки "Назад" для возврата в главное меню.
    """
    await show_main_menu(callback_query.message, state)

async def back_to_world_selection(callback_query: types.CallbackQuery, state: FSMContext):
    """
    Обработчик кнопки "Назад" при выборе мира.
    """
    await show_world_selection(callback_query.message, state)

def setup_menu_handlers(dp: Dispatcher, config: Config, database: Database, session_manager: SessionManager):
    """
    Настраивает обработчики меню для диспетчера.

    Args:
        dp (Dispatcher): Диспетчер для регистрации обработчиков.
    """
    dp.register_message_handler(show_main_menu, commands=['start', 'menu'], state='*')
    dp.register_callback_query_handler(show_main_menu, lambda c: c.data == 'back_to_main_menu', state='*')
    dp.register_callback_query_handler(continue_game, lambda c: c.data == 'continue_game', state=GameMenuStates.MAIN_MENU)
    dp.register_message_handler(show_language_selection, commands=['start', 'menu'], state='*')
    dp.register_callback_query_handler(set_language_handler, lambda c: c.data.startswith('set_lang:'), state=GameMenuStates.LANGUAGE_SELECTION)
    dp.register_callback_query_handler(change_language_handler, lambda c: c.data == 'change_language', state='*')
    dp.register_callback_query_handler(new_game_handler, lambda c: c.data == 'new_game', state=GameMenuStates.MAIN_MENU)
    dp.register_callback_query_handler(show_save_slots, lambda c: c.data == 'save_game', state=GameMenuStates.MAIN_MENU)
    dp.register_callback_query_handler(save_game_to_slot, lambda c: c.data.startswith('save_to_slot:'), state=GameMenuStates.SAVE_GAME)
    dp.register_callback_query_handler(show_load_slots, lambda c: c.data == 'load_game', state=GameMenuStates.MAIN_MENU)
    dp.register_callback_query_handler(load_game_from_slot, lambda c: c.data.startswith('load_from_slot:'), state=GameMenuStates.LOAD_GAME)
    dp.register_callback_query_handler(back_to_main_menu, lambda c: c.data == 'back_to_main_menu', state='*')
    dp.register_callback_query_handler(process_world_selection, lambda c: c.data.startswith('select_world:'), state=GameMenuStates.WORLD_SELECTION)
    dp.register_callback_query_handler(back_to_world_selection, lambda c: c.data == "back_to_worlds", state='*')
    dp.register_callback_query_handler(start_new_game, lambda c: c.data.startswith('start_game:'), state=GameMenuStates.WORLD_DESCRIPTION)
    dp.register_message_handler(handle_in_game_message, state=GameMenuStates.MAIN_MENU)
    

    logger.info("Обработчики меню успешно настроены")

