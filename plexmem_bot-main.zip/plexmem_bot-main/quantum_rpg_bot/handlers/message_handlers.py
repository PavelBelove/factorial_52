# quantum_rpg_bot/handlers/message_handlers.py

import logging
import asyncio
import re
from aiogram import types, Dispatcher
from aiogram.dispatcher import FSMContext
from aiogram.utils.markdown import escape_md
from aiogram.utils.exceptions import MessageNotModified
from config import Config
from database import Database
from agents.dialog_agent import DialogAgent
from memory.context_manager import ContextManager
from handlers.menu_handlers import GameMenuStates
from utils.fotmat_for_telegram import format_response_for_telegram

logger = logging.getLogger(__name__)

async def handle_user_message(message: types.Message, state: FSMContext):
    config = message.bot.get('config')
    database = message.bot.get('database')
    dialog_agent = message.bot.get('dialog_agent')
    context_manager = message.bot.get('context_manager')

    user_id = message.from_user.id
    user_data = await state.get_data()
    game_id = user_data.get('current_game_id')

    if not game_id:
        await message.answer("Извините, не могу найти вашу текущую игру. Пожалуйста, начните новую игру или загрузите существующую.")
        return

    user_message = message.text
    context = await context_manager.get_context(user_id, game_id)

    # Отправляем начальное сообщение-плейсхолдер 
    loading_message = await message.answer("Обдумываю ваш ответ...")
    
    # Запускаем анимацию загрузки
    loading_task = asyncio.create_task(animate_loading(loading_message))

    try:
        # Обработка сообщения через DialogAgent
        response = await dialog_agent.process(user_id, game_id, user_message, context, lambda: None)

        # Останавливаем анимацию загрузки
        loading_task.cancel()
        
        if response and isinstance(response, dict):
            # Форматирование ответа для Telegram
            formatted_response = format_response_for_telegram(response['response'])
            
            # Пытаемся изменить сообщение-плейсхолдер
            try:
                await loading_message.edit_text(formatted_response, parse_mode='MarkdownV2')
            except MessageNotModified:
                # Если сообщение не изменилось, отправляем новое
                await message.answer(formatted_response, parse_mode='MarkdownV2')

            # Обновление контекста и состояния игры
            try:
                await context_manager.update_context(
                    user_id, 
                    game_id, 
                    user_message, 
                    response['response'], 
                    response['state'],
                    response.get('requested_quanta', [])
                )
            except Exception as e:
                logger.error(f"Ошибка при обновлении контекста: {e}", exc_info=True)
            
            # Обновление состояния игры в базе данных
            await database.save_state(game_id, response['state'])
        else:
            await loading_message.edit_text("Произошла ошибка при обработке вашего сообщения.")
    except Exception as e:
        logger.info(f"Ошибка при обработке сообщения: {e}")
        await loading_message.edit_text("Произошла непредвиденная ошибка. Пожалуйста, попробуйте еще раз позже.")
    finally:
        # Убеждаемся, что задача анимации остановлена
        if not loading_task.done():
            loading_task.cancel()

async def animate_loading(message: types.Message):
    """
    Анимирует сообщение-плейсхолдер, добавляя звездочки.
    """
    loading_text = "Обдумываю ваш ответ... \n"
    dots = ""
    try:
        while True:
            if len(dots) > 13:
                dots = "֍"
            elif len(dots) % 2 == 1:
                dots += "֍"
            else:
                dots += "֎"
            await message.edit_text(f"{loading_text}{dots}")
            await asyncio.sleep(1)
    except asyncio.CancelledError:
        # Задача была отменена, ничего не делаем
        pass

def setup_message_handlers(dp: Dispatcher, config: Config, database: Database, dialog_agent: DialogAgent, context_manager: ContextManager):
    """
    Настраивает обработчики сообщений.
    """
    dp.register_message_handler(handle_user_message, state=GameMenuStates.IN_GAME)
    logger.info("Обработчики сообщений настроены")
