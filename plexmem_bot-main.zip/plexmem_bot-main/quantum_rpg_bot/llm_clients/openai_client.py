# quantum_rpg_bot/llm_clients/openai_client.py

import asyncio
import os
from typing import List, Dict, Any, Callable, AsyncGenerator
from config import Config
from .base_client import BaseLLMClient
from openai import AsyncOpenAI
from itertools import cycle

class OpenAIClient(BaseLLMClient):
    """
    Клиент для работы с OpenAI API с балансировкой ключей и обработкой исчерпанных ключей.
    """

    EXHAUSTED_MARKER = "#EXHAUSTED#"

    def __init__(self, config: Config):
        self.config = config
        self.api_keys = self._load_api_keys()
        self.current_key = next(self.api_keys)
        self.model = config.OPENAI_MODEL
        self.max_retries = config.MAX_RETRIES
        self.retry_delay = config.RETRY_DELAY
        self.timeout = config.GPT_TIMEOUT
        self.max_tokens = config.MAX_TOKENS
        self.temperature = config.TEMPERATURE
        self.top_p = config.TOP_P

    def _load_api_keys(self):
        """
        Загружает ключи API из файла .OAI.txt, пропуская исчерпанные ключи.
        """
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        self.file_path = os.path.join(base_dir, '.OAI.txt')
        try:
            with open(self.file_path, 'r') as file:
                keys = [line.strip() for line in file if line.strip() and not line.strip().startswith(self.EXHAUSTED_MARKER)]
            if not keys:
                raise ValueError("Все ключи в файле .OAI.txt исчерпаны или файл пуст.")
            return cycle(keys)
        except FileNotFoundError:
            raise FileNotFoundError(f"Файл .OAI.txt с ключами API не найден по пути: {self.file_path}")

    def _mark_key_as_exhausted(self, key: str):
        """
        Помечает исчерпанный ключ в файле .OAI.txt.
        """
        with open(self.file_path, 'r') as file:
            lines = file.readlines()
        
        with open(self.file_path, 'w') as file:
            for line in lines:
                if line.strip() == key:
                    file.write(f"{self.EXHAUSTED_MARKER}{line}")
                else:
                    file.write(line)
        
        # Перезагружаем ключи после обновления файла
        self.api_keys = self._load_api_keys()
        self.current_key = next(self.api_keys)

    def _get_client(self):
        return AsyncOpenAI(api_key=self.current_key)

    async def _handle_api_call(self, api_call: Callable):
        """
        Обрабатывает вызов API с учетом исчерпанных ключей и повторных попыток.
        """
        for attempt in range(self.max_retries):
            try:
                return await api_call()
            except Exception as e:
                if "insufficient_quota" in str(e).lower() or "максимальный месячный бюджет" in str(e).lower():
                    self._mark_key_as_exhausted(self.current_key)
                    self.current_key = next(self.api_keys)
                elif attempt == self.max_retries - 1:
                    raise
                await asyncio.sleep(self.retry_delay * (attempt + 1))

    async def get_completion(self, messages: List[Dict[str, str]], update_callback: Callable[[], Any] = None) -> str:
        async def api_call():
            client = self._get_client()
            response = await asyncio.wait_for(
                client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    max_tokens=self.max_tokens,
                    temperature=self.temperature,
                    top_p=self.top_p,
                ),
                timeout=self.timeout
            )
            return response.choices[0].message.content

        return await self._handle_api_call(api_call)

    async def get_completion_stream(self, messages: List[Dict[str, str]], update_callback: Callable[[], Any] = None) -> AsyncGenerator[str, None]:
        async def api_call():
            client = self._get_client()
            stream = await client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
                top_p=self.top_p,
                stream=True
            )
            async for chunk in stream:
                if chunk.choices[0].delta.content is not None:
                    yield chunk.choices[0].delta.content

        async for content in await self._handle_api_call(api_call):
            yield content