import os
from dotenv import load_dotenv
from localization.ru import RussianLocalization
from localization.en import EnglishLocalization

load_dotenv()

class Config:
    # Общие настройки
    TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
    DB_PATH = "database.sqlite"
    DEBUG_VERBOSE = False

    # Настройки локализации
    DEFAULT_LANGUAGE = "ru"
    AVAILABLE_LANGUAGES = {
        "ru": RussianLocalization(),
        "en": EnglishLocalization()
    }

    # Обновленные настройки LLM
    LLM_PROVIDER = os.getenv("LLM_PROVIDER", "OPENAI")  # Может быть 'GPT4FREE', 'GEMINI', 'GROQ', 'OPENROUTER', 'AIMLAPI' или 'OPENAI'
    
    ## Настройки для GPT4Free
    GPT4FREE_PROVIDER = "HuggingChat"
    GPT4FREE_MODEL = "command-r+"

    ## Настройки для Gemini
    GEMINI_API_KEYS = [key.strip() for key in os.getenv("GEMINI_API_KEYS", "").split(",") if key.strip()]

    ## Настройки для GROQ
    GROQ_API_KEY = os.getenv("GROQ_API_KEY")
    GROQ_MODEL = "mixtral-8x7b-32768"

    ## Настройки для OpenRouter
    OPENROUTER_API_KEYS = [key.strip() for key in os.getenv("OPENROUTER_API_KEYS", "").split(",") if key.strip()]
    OPENROUTER_MODEL = "openai/gpt-4o-mini-2024-07-18"

    ## Настройки для AIMLAPI
    AIMLAPI_API_KEYS = [key.strip() for key in os.getenv("AIMLAPI_API_KEYS", "").split(",") if key.strip()]
    AIMLAPI_MODEL = "gpt-4o-mini"

    ## Настройки для OpenAI
    OPENAI_MODEL = "gpt-4o-mini"  

    ## Общие настройки для LLM
    MAX_RETRIES = 3
    RETRY_DELAY = 2
    GPT_TIMEOUT = 120

    ## Общие параметры для LLM
    MAX_TOKENS = int(os.getenv("MAX_TOKENS", "2000"))
    TEMPERATURE = float(os.getenv("TEMPERATURE", "0.7"))
    TOP_P = float(os.getenv("TOP_P", "0.9"))
    TOP_K = int(os.getenv("TOP_K", "40"))
    REPETITION_PENALTY = float(os.getenv("REPETITION_PENALTY", "1.2"))

    # Настройки для логирования
    DEBUG_VERBOSE = True
    DEBUG_JSON_PROCESSING = True
    DEBUG_FIXER_AGENT = True
    DEBUG_SUM_RESPONSE = True
    DEBUG_STATS = True
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    LOG_DIR = os.path.join(BASE_DIR, "logs")

    # Настройки для игровой логики
    DICE_ROLL_PAIRS = 1
    UNDO_TURNS = 3
    MAX_RETRIES = 3
    SUMMARIZE_INTERVAL = 4
    FIRST_SUMMARIZATION_INTERVAL = 6
    SUMMARIZER_QUANTA_COUNT = 7  # #$ Количество квантов для передачи Суму
    SUMMARIZER_CONTEXT_TURNS = 8
    MAX_CONTEXT_TURNS = 10
    MAX_CONTEXT_LENGTH = 20000
    MAX_MESSAGE_LENGTH = 4096
    
    # Пути к файлам с промптами
    PROMPTS_DIR = os.path.join(os.path.dirname(__file__), "prompts")
    ROLE_PROMPT_FILE = os.path.join(PROMPTS_DIR, "dialog_prompt.txt")
    CONTEXT_SUMMARIZATION_PROMPT_FILE = os.path.join(PROMPTS_DIR, "summarization_prompt.txt")

    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    WORLDS_DIR = os.path.join(BASE_DIR, 'quantum_rpg_bot', 'prompts', 'worlds')


    # Загрузка промптов
    ROLE_PROMPT = None
    CONTEXT_SUMMARIZATION_PROMPT = None

    def get_openai_keys(self) -> list[str]:
        keys = []
        file_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), self.OPENAI_KEYS_FILE)
        if os.path.exists(file_path):
            with open(file_path, 'r') as file:
                keys = [line.strip() for line in file if line.strip()]
        return keys

    def get_localization(self, language_code: str):
        return self.AVAILABLE_LANGUAGES.get(language_code, self.AVAILABLE_LANGUAGES[self.DEFAULT_LANGUAGE])

    @classmethod
    def load_all_prompts(cls):
        cls.ROLE_PROMPT = cls.load_prompt(cls.ROLE_PROMPT_FILE)
        cls.CONTEXT_SUMMARIZATION_PROMPT = cls.load_prompt(cls.CONTEXT_SUMMARIZATION_PROMPT_FILE)

    @staticmethod
    def load_prompt(file_path):
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read().strip()

    @classmethod
    def get_llm_client(cls):
        if cls.LLM_PROVIDER == "GPT4FREE":
            from llm_clients.gpt4free_client import GPT4FreeClient
            return GPT4FreeClient(cls)
        elif cls.LLM_PROVIDER == "GEMINI":
            from llm_clients.gemini_client import GeminiClient
            return GeminiClient(cls)
        elif cls.LLM_PROVIDER == "GROQ":
            from llm_clients.groq_client import GroqClient
            return GroqClient(cls)
        elif cls.LLM_PROVIDER == "OPENROUTER":
            from llm_clients.openrouter_client import OpenRouterClient
            return OpenRouterClient(cls)
        elif cls.LLM_PROVIDER == "AIMLAPI":
            from llm_clients.aimlapi_client import AIMLAPIClient
            return AIMLAPIClient(cls)
        elif cls.LLM_PROVIDER == "OPENAI":
            from llm_clients.openai_client import OpenAIClient
            return OpenAIClient(cls)
        else:
            raise ValueError(f"Неизвестный провайдер LLM: {cls.LLM_PROVIDER}")


# Загрузка всех промптов при импорте конфигурации
Config.load_all_prompts()