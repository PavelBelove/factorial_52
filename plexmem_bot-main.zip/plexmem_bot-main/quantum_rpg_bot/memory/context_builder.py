import logging
from typing import List, Dict, Any
from collections import Counter
from config import Config
from database import Database
from memory.quantum import QuantumMemory
from utils.dice_roller import generate_dice_rolls, format_dice_rolls
from utils.game_settings import GameSettings



class ContextBuilder:
    def __init__(self, config: Config, quantum_memory: QuantumMemory, database: Database):
        self.config = config
        self.quantum_memory = quantum_memory
        self.db = database
        self.logger = logging.getLogger(__name__)
        self.current_context = {}
        self.quanta_request_counter = Counter()

    async def set_context(self, game_id: int, game_data: Dict[str, Any], quanta: List[Dict[str, Any]], state: Dict[str, Any], summary: str):
        """
        Устанавливает контекст для игры.

        Args:
            game_id (int): ID игры.
            game_data (Dict[str, Any]): Данные игры.
            quanta (List[Dict[str, Any]]): Список квантов.
            state (Dict[str, Any]): Текущее состояние игры.
            summary (str): Последнее саммари игры.
        """

        # Устанавливаем значения по умолчанию для новой игры
        if not state:
            state = {
                'difficulty': 'intermediate',  # Опытный путешественник
                'censorship': 'teen'  # Приключенческая повесть
            }

        self.current_context = {
            "game_id": game_id,
            "game_data": game_data,
            "quanta": quanta,
            "state": state,
            "summary": summary
        }

        await self.db.save_state(game_id, state)

        self.logger.info(f"Контекст установлен для игры {game_id}")

    async def build_context(self, user_id: int, game_id: int) -> List[Dict[str, str]]:
        # #@ ContextManager
        # Этот метод вызывается для построения контекста для ГМ (DialogAgent)
        context = []

        try:
            game_data = await self.db.load_game(user_id, game_id)
            if game_data:
                context.append({"role": "system", "content": f"Описание мира: {game_data['world_description']}"})

                # Получаем текущее состояние
                current_state = await self.db.get_current_state(game_id) or {}
                language = current_state.get('language', self.config.DEFAULT_LANGUAGE)
                difficulty = current_state.get('difficulty', 'intermediate')
                censorship = current_state.get('censorship', 'teen')
                adult_content = current_state.get('adult_content', False)

                # Объединяем все настройки в одно сообщение
                settings_prompt = f"{GameSettings.get_language_prompt(language)} {GameSettings.get_difficulty_prompt(difficulty)} "
                if adult_content:
                    settings_prompt += f" {GameSettings.get_adult_content_prompt()}"
                else:
                    settings_prompt += f" {GameSettings.get_censorship_prompt(censorship)}"

                context.append({"role": "system", "content": settings_prompt})

            latest_summary = await self.db.get_latest_summary(game_id)
            if latest_summary:
                context.append({"role": "assistant", "content": f"Текущее состояние игры: {latest_summary}"})
            else:
                context.append({"role": "assistant", "content": "Начало новой игры. Предыдущей истории нет."})

            recent_turns = await self.db.get_recent_turns(game_id, self.config.MAX_CONTEXT_TURNS)
            if recent_turns:
                for turn in recent_turns:
                    context.append({"role": "user", "content": turn.get('user_message', '')})
                    context.append({"role": "assistant", "content": turn.get('assistant_response', '')})

            # Генерация и форматирование бросков костей
            dice_rolls = generate_dice_rolls(self.config.DICE_ROLL_PAIRS)
            formatted_rolls = format_dice_rolls(dice_rolls)
            context.append({"role": "user", "content": f"Броски костей: {', '.join(formatted_rolls)}"})

            return self.trim_context(context)
        except Exception as e:
            self.logger.error(f"Ошибка при построении контекста: {e}")
            raise

    async def build_summarizer_context(self, game_id: int) -> List[Dict[str, str]]:
        # #@ SummarizerAgent
        # Этот метод вызывается для построения контекста для Сума (SummarizerAgent)
        context = []

        try:
            latest_summary = await self.db.get_latest_summary(game_id)
            if latest_summary:
                context.append({"role": "assistant", "content": f"{latest_summary}"})

            recent_turns = await self.db.get_recent_turns(game_id, self.config.SUMMARIZER_CONTEXT_TURNS)
            for turn in recent_turns:
                context.append({"role": "user", "content": turn['user_message']})
                context.append({"role": "assistant", "content": turn['assistant_response']})
                self.update_quanta_request_counter(turn.get('requested_quanta', []))

            most_requested_quanta = self.get_most_requested_quanta(self.config.SUMMARIZER_QUANTA_COUNT)
            relevant_quanta = await self.quantum_memory.get_quanta_by_names(game_id, most_requested_quanta)
            if relevant_quanta:
                quanta_context = "Релевантные кванты:\n" + "\n".join([f"{q['name']}: {q['summary']}" for q in relevant_quanta])
                context.append({"role": "system", "content": quanta_context})

                self.logger.info(f"Содержимое контекста для суммаризатора: {context}")

            return context
        except Exception as e:
            self.logger.error(f"Ошибка при построении контекста для суммаризатора: {e}")
            raise

    def update_quanta_request_counter(self, requested_quanta: List[str]):
        # #% Рассмотреть возможность добавления "веса" к счетчику
        # Например, более новые запросы могут иметь больший вес
        self.quanta_request_counter.update(requested_quanta)

    def get_most_requested_quanta(self, count: int) -> List[str]:
        return [name for name, _ in self.quanta_request_counter.most_common(count)]

    def reset_quanta_request_counter(self):
        # #! Этот метод следует вызывать после каждой суммаризации
        self.quanta_request_counter.clear()

    def trim_context(self, context: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """
        Обрезает контекст до максимально допустимой длины.

        Args:
            context (List[Dict[str, str]]): Полный контекст.

        Returns:
            List[Dict[str, str]]: Обрезанный контекст.
        """
        total_length = sum(len(msg['content']) for msg in context)
        
        while total_length > self.config.MAX_CONTEXT_LENGTH and len(context) > 3:
            for i in range(1, len(context)):
                if context[i]['role'] != 'system':
                    removed_message = context.pop(i)
                    total_length -= len(removed_message['content'])
                    break

        return context
    
