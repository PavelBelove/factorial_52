# quantum_rpg_bot/memory/quantum.py

import json
from typing import Dict, List, Any, Optional

class QuantumMemory:
    def __init__(self, database):
        """
        Инициализация объекта квантовой памяти.

        Args:
            database: Объект для работы с базой данных.
        """
        self.db = database

    async def save_quantum(self, game_id: int, name: str, quantum_data: Dict[str, Any]) -> None:
        """
        Сохранение кванта в базу данных.

        Args:
            game_id (int): ID игры.
            name (str): Уникальное имя кванта.
            quantum_data (Dict[str, Any]): Данные кванта.
        """
        await self.db.save_quantum(game_id, name, quantum_data)

    async def update_quantum(self, game_id: int, name: str, updates: Dict[str, Any]) -> None:
        """
        Обновление существующего кванта.

        Args:
            game_id (int): ID игры.
            name (str): Уникальное имя кванта.
            updates (Dict[str, Any]): Словарь с обновлениями для кванта.
        """
        current_quantum = await self.get_quantum(game_id, name)
        if current_quantum:
            current_quantum.update(updates)
            await self.db.save_quantum(game_id, name, current_quantum)

    async def get_quantum(self, game_id: int, name: str) -> Optional[Dict[str, Any]]:
        """
        Получение кванта из базы данных.

        Args:
            game_id (int): ID игры.
            name (str): Уникальное имя кванта.

        Returns:
            Optional[Dict[str, Any]]: Данные кванта или None, если квант не найден.
        """
        return await self.db.get_quantum(game_id, name)


    async def get_quanta_by_names(self, game_id: int, names: List[str]) -> List[Dict[str, Any]]:
        # #@ ContextBuilder
        # Этот метод используется для получения квантов по их именам
        quanta = []
        for name in names:
            quantum = await self.get_quantum(game_id, name)
            if quantum:
                quanta.append(quantum)
        return quanta
    
    async def get_related_quanta(self, game_id: int, name: str) -> List[Dict[str, Any]]:
        """
        Получение связанных квантов.

        Args:
            game_id (int): ID игры.
            name (str): Уникальное имя кванта.

        Returns:
            List[Dict[str, Any]]: Список связанных квантов.
        """
        quantum = await self.get_quantum(game_id, name)
        if not quantum:
            return []
        
        related_quanta = []
        for related_name, relation_type in quantum['related_quanta'].items():
            related_quantum = await self.db.get_quantum(game_id, related_name)
            if related_quantum:
                related_quanta.append({
                    "name": related_name,
                    "type": related_quantum['type'],
                    "summary": related_quantum['summary'],
                    "relation": relation_type
                })
        return related_quanta


    async def get_all_quanta(self, game_id: int) -> List[Dict[str, Any]]:
        """
        Получает все кванты для указанной игры.

        Args:
            game_id (int): ID игры.

        Returns:
            List[Dict[str, Any]]: Список всех квантов игры.
        """
        return await self.db.get_all_quanta(game_id)
