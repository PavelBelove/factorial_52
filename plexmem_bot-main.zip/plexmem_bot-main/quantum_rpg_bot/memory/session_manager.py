# quantum_rpg_bot/session_manager.py

"""
Модуль для управления игровыми сессиями в Quantum RPG Bot.

Этот модуль отвечает за создание, сохранение, загрузку и управление игровыми сессиями.
Он централизует логику работы с игровыми данными, обеспечивая согласованность
между различными компонентами системы.
"""

import json
import logging
from typing import Dict, Any, Optional
from config import Config
from database import Database
from memory.context_manager import ContextManager
from agents.dialog_agent import DialogAgent

class SessionManager:
    def __init__(self, config: Config, database: Database, context_manager: ContextManager, dialog_agent: DialogAgent):
        """
        Инициализирует менеджер сессий.

        Args:
            config (Config): Конфигурация приложения.
            database (Database): Объект для работы с базой данных.
            context_manager (ContextManager): Менеджер контекста игры.
            dialog_agent (DialogAgent): Агент для обработки диалогов.
        """
        self.config = config
        self.db = database
        self.context_manager = context_manager
        self.dialog_agent = dialog_agent
        self.logger = logging.getLogger(__name__)

    async def create_new_game(self, user_id: int, world_id: str, language: str) -> Dict[str, Any]:
        """
        Создает новую игру для пользователя.
        """
        self.logger.info(f"Создание новой игры для пользователя {user_id}, мир {world_id}")
        
        # Создание новой игры в БД
        game_id = await self.db.create_new_game(user_id, world_id)
        
        # Инициализация контекста
        await self.context_manager.initialize_context(user_id, game_id, world_id, language)
        
        # Обновление состояния пользователя
        await self.db.update_user_state(user_id, game_id, False)
        
        # Получение информации о созданной игре
        game_info = await self.db.get_game_info(game_id)
        
        self.logger.info(f"Новая игра создана: {game_info}")
        return game_info

    async def save_game(self, user_id: int, game_id: int, slot: int) -> bool:
        """
        Сохраняет текущее состояние игры.
        """
        self.logger.info(f"Сохранение игры {game_id} для пользователя {user_id} в слот {slot}")
        
        try:
            # Получение текущего контекста игры
            game_context = await self.context_manager.get_context(user_id, game_id)
            
            # Получение данных игры
            game_data = await self.db.get_game_info(game_id)
            if not game_data:
                raise ValueError("Не удалось получить данные игры")

            # Сохранение игры в БД
            await self.db.save_game(user_id, game_id, game_data['world_id'], json.dumps(game_context), slot)
            
            # Обновление флага сохранения
            await self.db.update_user_state(user_id, game_id, True)
            
            self.logger.info(f"Игра {game_id} успешно сохранена в слот {slot}")
            return True
        except Exception as e:
            self.logger.error(f"Ошибка при сохранении игры {game_id}: {str(e)}")
            return False
    
    async def load_game(self, user_id: int, game_id: int) -> Optional[Dict[str, Any]]:
        """
        Загружает сохраненную игру.
        """
        self.logger.info(f"Загрузка игры {game_id} для пользователя {user_id}")
        
        try:
            # Загрузка данных игры из БД
            game_data = await self.db.load_game(user_id, game_id)
            
            if game_data:
                # Загрузка контекста
                context_loaded = await self.load_game_context(user_id, game_id)
                if not context_loaded:
                    raise Exception("Failed to load game context")
                
                # Обновление состояния пользователя
                await self.db.update_user_state(user_id, game_id, True)
                
                self.logger.info(f"Игра {game_id} успешно загружена")
                return game_data
            else:
                self.logger.warning(f"Игра {game_id} не найдена")
                return None
        except Exception as e:
            self.logger.error(f"Ошибка при загрузке игры {game_id}: {str(e)}")
            return None

    async def get_initial_message(self, user_id: int, game_id: int, language: str) -> str:
        """
        Получает начальное сообщение для новой игры.

        Args:
            user_id (int): ID пользователя.
            game_id (int): ID игры.
            language (str): Выбранный язык.

        Returns:
            str: Начальное сообщение для игры.
        """
        self.logger.info(f"Получение начального сообщения для игры {game_id}")
        
        game_info = await self.db.get_game_info(game_id)
        world_id = game_info['world_id']
        
        loc = self.config.get_localization(language)
        initial_message = loc.get_initial_game_message(world_id)
        
        self.logger.info(f"Начальное сообщение для игры {game_id}: {initial_message}")
        return initial_message

    async def process_initial_message(self, user_id: int, game_id: int, initial_message: str) -> str:
        """
        Обрабатывает начальное сообщение через DialogAgent.

        Args:
            user_id (int): ID пользователя.
            game_id (int): ID игры.
            initial_message (str): Начальное сообщение.

        Returns:
            str: Ответ DialogAgent на начальное сообщение.
        """
        self.logger.info(f"Начало обработки начального сообщения для игры {game_id}")
        
        initial_context = await self.context_manager.get_context(user_id, game_id)
        
        self.logger.info(f"Отправка начального сообщения в DialogAgent для игры {game_id}")
        response = await self.dialog_agent.process(
            user_id, game_id, initial_message, initial_context, lambda: None
        )
        
        self.logger.info(f"Получен ответ от DialogAgent для игры {game_id}")
        
        if isinstance(response, dict):
            response_text = response.get('response', '')
            new_state = response.get('state', {})
            requested_quanta = response.get('requested_quanta', [])
            
            await self.context_manager.update_context(
                user_id, game_id, initial_message, response_text, new_state, requested_quanta
            )
            self.logger.info(f"Контекст обновлен для игры {game_id}")
            return response_text
        else:
            self.logger.error(f"Неожиданный формат ответа от DialogAgent для игры {game_id}")
            return str(response)
        

        
    async def get_user_games(self, user_id: int) -> list[Dict[str, Any]]:
        """
        Получает список игр пользователя.

        Args:
            user_id (int): ID пользователя.

        Returns:
            List[Dict[str, Any]]: Список игр пользователя.
        """
        return await self.db.get_user_games(user_id)

    async def delete_game(self, user_id: int, game_id: int) -> bool:
        """
        Удаляет сохраненную игру.

        Args:
            user_id (int): ID пользователя.
            game_id (int): ID игры для удаления.

        Returns:
            bool: True, если удаление успешно, иначе False.
        """
        self.logger.info(f"Удаление игры {game_id} для пользователя {user_id}")
        
        try:
            await self.db.delete_game(user_id, game_id)
            self.logger.info(f"Игра {game_id} успешно удалена")
            return True
        except Exception as e:
            self.logger.error(f"Ошибка при удалении игры {game_id}: {e}")
            return False
        
    async def get_game_in_slot(self, user_id: int, slot: int) -> Optional[Dict[str, Any]]:
        """
        Получает информацию об игре в указанном слоте.
        """
        try:
            game_info = await self.db.get_game_in_slot(user_id, slot)
            return game_info
        except Exception as e:
            self.logger.error(f"Ошибка при получении информации об игре в слоте {slot}: {e}")
            return None

    async def get_recent_turns(self, game_id: int, num_turns: int = 5) -> list[Dict[str, str]]:
        """
        Получает последние ходы для указанной игры.
        """
        try:
            recent_turns = await self.db.get_recent_turns(game_id, num_turns)
            return recent_turns
        except Exception as e:
            self.logger.error(f"Ошибка при получении последних ходов для игры {game_id}: {e}")
            return []
        
    async def load_game_context(self, user_id: int, game_id: int) -> bool:
        """
        Загружает контекст игры, используя ContextManager.

        Args:
            user_id (int): ID пользователя.
            game_id (int): ID игры.

        Returns:
            bool: True, если контекст успешно загружен, False в противном случае.
        """
        try:
            await self.context_manager.load_context(user_id, game_id)
            return True
        except Exception as e:
            self.logger.error(f"Ошибка при загрузке контекста игры {game_id}: {str(e)}")
            return False

    async def update_saved_games(self, user_id: int):
        """
        Обновляет информацию о сохраненных играх пользователя.
        """
        try:
            # Получаем обновленный список сохраненных игр
            saved_games = await self.db.get_user_games(user_id)
            
            # Здесь можно добавить дополнительную логику, если нужно
            # Например, обновление кэша или уведомление других частей системы
            
            self.logger.info(f"Обновлена информация о сохраненных играх для пользователя {user_id}")
        except Exception as e:
            self.logger.error(f"Ошибка при обновлении информации о сохраненных играх: {str(e)}")
