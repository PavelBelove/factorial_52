# quantum_rpg_bot/memory/context_manager.py

import json  
import logging
import os
import logging
from typing import List, Dict, Any
from config import Config
from database import Database
from memory.quantum import QuantumMemory
from memory.context_builder import ContextBuilder

class ContextManager:
    def __init__(self, config: Config, quantum_memory: QuantumMemory, 
                 context_builder: ContextBuilder, database: Database):
        self.config = config
        self.quantum_memory = quantum_memory
        self.context_builder = context_builder
        self.db = database
        self.logger = logging.getLogger(__name__)
        self.summarizer_agent = None  # Будет установлено позже
        self.turn_counter = 0
        self.first_summarization = True

    def set_summarizer_agent(self, summarizer_agent):
        self.summarizer_agent = summarizer_agent



    async def initialize_context(self, user_id: int, game_id: int, world_id: str, language: str):
        """
        Инициализирует контекст для новой игры.

        Args:
            user_id (int): ID пользователя.
            game_id (int): ID игры.
            world_id (str): ID выбранного мира.
            language (str): Выбранный язык.
        """
        # self.logger.info(f"Инициализация контекста для пользователя {user_id}, игра {game_id}, мир {world_id}, язык {language}")
        
        # Загрузка данных мира
        world_data = self.load_world_data(world_id, language)
        
        # Разделение данных
        world_description = world_data.get('world', {})
        initial_summary = world_data.get('summary', {})
        initial_quanta = world_data.get('quanta', [])

        # Сохранение данных игры
        await self.db.save_game(user_id, game_id, world_id, json.dumps(world_description), json.dumps(initial_summary))

        # Сохранение начального саммари
        await self.db.save_summary(game_id, json.dumps(initial_summary, ensure_ascii=False))

        # Сохранение начальных квантов
        for quantum in initial_quanta:
            await self.quantum_memory.save_quantum(game_id, quantum['name'], quantum)

        # Установка флагов для суммаризации
        self.turn_counter = 0
        self.first_summarization = True

        # Создание начального состояния игры
        initial_state = {
            "turn_number": 0,
            "language": language,
            "metrics": {
                "engagement": 0,
                "knowledge": 0,
                "satisfaction": 0
            }
        }
        await self.db.save_state(game_id, initial_state)

        # self.logger.info(f"Контекст успешно инициализирован для пользователя {user_id}, игра {game_id}")

    def load_world_data(self, world_id: str, language: str) -> Dict[str, Any]:
        """
        Загружает данные мира из соответствующего JSON-файла.

        Args:
            world_id (str): ID мира.
            language (str): Выбранный язык.

        Returns:
            Dict[str, Any]: Данные мира.
        """
        file_path = os.path.join(self.config.WORLDS_DIR, f"{world_id}.json")
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)

    async def update_context(self, user_id: int, game_id: int, user_message: str, assistant_response: str, 
                             state_updates: Dict[str, Any], requested_quanta: List[str]):
        """
        Обновляет контекст игры после каждого хода.

        Args:
            user_id (int): ID пользователя.
            game_id (int): ID игры.
            user_message (str): Сообщение пользователя.
            assistant_response (str): Ответ ассистента.
            state_updates (Dict[str, Any]): Обновления состояния игры.
            requested_quanta (List[str]): Список запрошенных квантов.
        """
        self.logger.info(f"Обновление контекста: user_id={user_id}, game_id={game_id}, turn_number={state_updates.get('turn_number', 0)}")
        
        await self.db.save_turn(game_id, user_id, user_message, assistant_response)
        await self.db.save_state(game_id, state_updates)

        self.turn_counter += 1
        self.logger.info(f"Текущий номер хода: {self.turn_counter}")

        if self.should_summarize():
            self.logger.info(f"Вызов суммаризации для игры {game_id}, ход {self.turn_counter}")
            summary_data = await self.summarizer_agent.process(game_id)
            await self.update_summarization(game_id, summary_data)
            self.turn_counter = 0
            self.first_summarization = False
        else:
            self.logger.info(f"Суммаризация не требуется для игры {game_id}, ход {self.turn_counter}")

        if self.config.DEBUG_STATS:
            self.logger.debug(f"Обновление контекста для пользователя {user_id}, игра {game_id}:")
            self.logger.debug(f"Сообщение пользователя: {user_message}")
            self.logger.debug(f"Ответ ассистента: {assistant_response}")
            self.logger.debug(f"Обновления состояния: {json.dumps(state_updates, ensure_ascii=False, indent=2)}")
            self.logger.debug(f"Запрошенные кванты: {requested_quanta}")

    async def update_summarization(self, game_id: int, summary_data: Dict[str, Any]):
        """
        Обновляет суммаризацию и кванты.

        Args:
            game_id (int): ID игры.
            summary_data (Dict[str, Any]): Словарь с обновленным саммари и квантами.
        """
        self.logger.info(f"Обновление суммаризации для игры {game_id}")
        
        summary = summary_data.get("summary", {})
        updated_quanta = summary_data.get("quanta", [])

        await self.db.save_summary(game_id, json.dumps(summary, ensure_ascii=False))
        for quantum in updated_quanta:
            await self.quantum_memory.update_quantum(
                game_id, 
                quantum['name'], 
                {
                    'summary': quantum['summary'],
                    'details': json.dumps(quantum.get('details', {}), ensure_ascii=False),
                    'related_quanta': json.dumps(quantum.get('related_quanta', {}), ensure_ascii=False),
                    'attention': quantum.get('attention', 5)
                }
            )

    async def get_turn_history(self, game_id: int, num_turns: int) -> List[Dict[str, str]]:
        """
        Получает историю ходов для игры.

        Args:
            game_id (int): ID игры.
            num_turns (int): Количество ходов для получения.

        Returns:
            List[Dict[str, str]]: Список ходов.
        """
        return await self.db.get_recent_turns(game_id, num_turns)

    async def load_context(self, user_id: int, game_id: int):
        """
        Загружает контекст для существующей игры.

        Args:
            user_id (int): ID пользователя.
            game_id (int): ID игры.
        """
        self.logger.info(f"Загрузка контекста для пользователя {user_id}, игра {game_id}")
        
        try:
            game_data = await self.db.load_game(user_id, game_id)
            if game_data:
                quanta = await self.quantum_memory.get_all_quanta(game_id)
                state = await self.db.get_current_state(game_id)
                summary = await self.db.get_latest_summary(game_id)

                self.turn_counter = 0
                self.first_summarization = False

                await self.context_builder.set_context(game_id, game_data, quanta, state, summary)

                self.logger.info(f"Контекст успешно загружен для пользователя {user_id}, игра {game_id}")
            else:
                self.logger.error(f"Не удалось загрузить данные игры для пользователя {user_id}, игра {game_id}")
        except Exception as e:
            self.logger.error(f"Ошибка при загрузке контекста для пользователя {user_id}, игра {game_id}: {str(e)}")
            raise

    async def get_context(self, user_id: int, game_id: int) -> List[Dict[str, str]]:
        # #@ DialogAgent
        # Этот метод вызывается для получения контекста для ГМ
        return await self.context_builder.build_context(user_id, game_id)

    async def get_summarizer_context(self, game_id: int) -> List[Dict[str, str]]:
        # #@ SummarizerAgent
        # Этот метод вызывается для построения контекста для Сума (SummarizerAgent)
        context = await self.context_builder.build_summarizer_context(game_id)
        self.context_builder.reset_quanta_request_counter()
        return context
    
    def should_summarize(self) -> bool:
        if self.first_summarization:
            return self.turn_counter >= self.config.FIRST_SUMMARIZATION_INTERVAL
        else:
            return self.turn_counter >= self.config.SUMMARIZE_INTERVAL